package org.example.config;
import java.sql.Connection;
import java.sql.SQLException;

public interface IGerenciadorConexaoBD {
        void abrirConexao();
        Connection obterConexao() throws SQLException;
        void fecharConexao();
}
