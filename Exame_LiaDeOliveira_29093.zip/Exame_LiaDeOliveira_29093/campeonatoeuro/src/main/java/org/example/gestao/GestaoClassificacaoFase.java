package org.example.gestao;

import org.example.dao.ClassificacaoFaseDAO;
import org.example.modelos.ClassificacaoFase;

import java.util.List;
import java.util.Scanner;

public class GestaoClassificacaoFase {
    private final ClassificacaoFaseDAO classificacaoFaseDAO;
    private final Scanner scanner;

    public GestaoClassificacaoFase() {
        this.classificacaoFaseDAO = new ClassificacaoFaseDAO();
        this.scanner = new Scanner(System.in);
    }

    public void menu() {
        int opcao;
        do {
            System.out.println("Gestão de Classificação de Fases");
            System.out.println("1. Adicionar Classificação de Fase");
            System.out.println("2. Listar Classificações de Fases");
            System.out.println("3. Atualizar Classificação de Fase");
            System.out.println("4. Remover Classificação de Fase");
            System.out.println("5. Voltar ao Menu Principal");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (opcao) {
                case 1 -> adicionarClassificacaoFase();
                case 2 -> listarClassificacoesFase();
                case 3 -> atualizarClassificacaoFase();
                case 4 -> removerClassificacaoFase();
                case 5 -> System.out.println("Voltando ao Menu Principal...");
                default -> System.out.println("Opção inválida! Tente novamente.");
            }
        } while (opcao != 5);
    }

    private void adicionarClassificacaoFase() {
        System.out.print("Digite o ID da fase: ");
        int idFase = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        System.out.print("Digite o ID da seleção: ");
        int idSelecao = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        System.out.print("Digite a posição: ");
        int posicao = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        ClassificacaoFase classificacaoFase = new ClassificacaoFase(idFase, idSelecao, posicao);

        classificacaoFaseDAO.inserir(classificacaoFase);
        System.out.println("Classificação de Fase adicionada com sucesso!");
    }

    private void listarClassificacoesFase() {
        List<ClassificacaoFase> classificacoes = classificacaoFaseDAO.buscarTodos();
        if (classificacoes.isEmpty()) {
            System.out.println("Nenhuma classificação de fase encontrada.");
        } else {
            System.out.println("Lista de Classificações de Fase:");
            for (ClassificacaoFase cf : classificacoes) {
                System.out.println(cf);
            }
        }
    }

    private void atualizarClassificacaoFase() {
        System.out.print("Digite o ID da classificação de fase que deseja atualizar: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        ClassificacaoFase classificacaoFase = classificacaoFaseDAO.buscaPorId(id);
        if (classificacaoFase == null) {
            System.out.println("Classificação de Fase não encontrada.");
            return;
        }

        System.out.print("Digite o novo ID da fase: ");
        int idFase = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        System.out.print("Digite o novo ID da seleção: ");
        int idSelecao = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        System.out.print("Digite a nova posição: ");
        int posicao = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        classificacaoFase.setIdFase(idFase);
        classificacaoFase.setIdSelecao(idSelecao);
        classificacaoFase.setPosicao(posicao);

        classificacaoFaseDAO.atualizar(classificacaoFase);
        System.out.println("Classificação de Fase atualizada com sucesso!");
    }

    private void removerClassificacaoFase() {
        System.out.print("Digite o ID da classificação de fase que deseja remover: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        classificacaoFaseDAO.eliminar(id);
        System.out.println("Classificação de Fase removida com sucesso!");
    }
}
