package org.example.dao;

import org.example.config.GerenciadorConexaoBD;
import org.example.modelos.Selecao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SelecaoDAO implements IDAO<Selecao>{

    private final GerenciadorConexaoBD gerenciadorConexao;

    public SelecaoDAO() {
        this.gerenciadorConexao = new GerenciadorConexaoBD();
    }

    public void inserir(Selecao selecao) {
        String sql = "INSERT INTO selecao (idSelecao, nome, idPais) VALUES (?, ?, ?)";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, selecao.getIdSelecao());
            statement.setString(2, selecao.getNome());
            statement.setInt(3, selecao.getIdPais());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Selecao buscaPorId(int id) {
        String sql = "SELECT * FROM selecao WHERE idSelecao = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return extractSelecaoFromResultSet(resultSet);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Selecao> buscarTodos() {
        List<Selecao> selecoes = new ArrayList<>();
        String sql = "SELECT * FROM selecao";
        try (Connection connection = gerenciadorConexao.obterConexao();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {
            while (resultSet.next()) {
                selecoes.add(extractSelecaoFromResultSet(resultSet));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return selecoes;
    }

    public void atualizar(Selecao selecao) {
        String sql = "UPDATE selecao SET nome = ?, idPais = ? WHERE idSelecao = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, selecao.getNome());
            statement.setInt(2, selecao.getIdPais());
            statement.setInt(3, selecao.getIdSelecao());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void eliminar(int id) {
        String sql = "DELETE FROM selecao WHERE idSelecao = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private Selecao extractSelecaoFromResultSet(ResultSet resultSet) throws SQLException {
        Selecao selecao = new Selecao();
        selecao.setIdSelecao(resultSet.getInt("idSelecao"));
        selecao.setNome(resultSet.getString("nome"));
        selecao.setIdPais(resultSet.getInt("idPais"));
        return selecao;
    }
}

