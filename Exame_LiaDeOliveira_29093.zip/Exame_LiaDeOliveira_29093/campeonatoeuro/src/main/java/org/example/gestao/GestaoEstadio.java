package org.example.gestao;

import org.example.dao.CidadeDAO;
import org.example.dao.EstadioDAO;
import org.example.modelos.Cidade;
import org.example.modelos.Estadio;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class GestaoEstadio {
    private final EstadioDAO estadioDAO;
    private final CidadeDAO cidadeDAO;
    private final Scanner scanner;

    public GestaoEstadio() {
        this.estadioDAO = new EstadioDAO();
        this.cidadeDAO = new CidadeDAO();
        this.scanner = new Scanner(System.in);
    }

    public void menu() {
        int opcao;
        do {
            System.out.println("Gestão de Estádios");
            System.out.println("1. Adicionar Estádio");
            System.out.println("2. Listar Estádios");
            System.out.println("3. Atualizar Estádio");
            System.out.println("4. Remover Estádio");
            System.out.println("5. Voltar ao Menu Principal");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (opcao) {
                case 1 -> adicionarEstadio();
                case 2 -> listarEstadios();
                case 3 -> atualizarEstadio();
                case 4 -> removerEstadio();
                case 5 -> System.out.println("Voltando ao Menu Principal...");
                default -> System.out.println("Opção inválida! Tente novamente.");
            }
        } while (opcao != 5);
    }

    private void adicionarEstadio() {
        List<Cidade> cidades = cidadeDAO.buscarTodos();
        if (cidades.isEmpty()) {
            System.out.println("Nenhuma cidade encontrada. Adicione cidades primeiro.");
            return;
        }

        System.out.print("Digite o nome do estádio: ");
        String nome = scanner.nextLine();

        System.out.print("Digite a capacidade do estádio: ");
        int capacidade = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        System.out.println("Escolha o ID da cidade da lista:");
        for (Cidade cidade : cidades) {
            System.out.println(cidade.getIdCidade() + ". " + cidade.getNome());
        }
        System.out.print("ID da cidade: ");
        int idCidade = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        Estadio estadio = new Estadio();
        estadio.setNome(nome);
        estadio.setCapacidade(capacidade);
        estadio.setIdCidade(idCidade);

        estadioDAO.inserir(estadio);
        System.out.println("Estádio adicionado com sucesso!");
    }

    private void listarEstadios() {
        List<Estadio> estadios = estadioDAO.buscarTodos();
        if (estadios.isEmpty()) {
            System.out.println("Nenhum estádio encontrado.");
        } else {
            System.out.println("Lista de Estádios:");
            for (Estadio estadio : estadios) {
                System.out.println(estadio);
            }
        }
    }

    private void atualizarEstadio() {
        System.out.print("Digite o ID do estádio que deseja atualizar: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        Estadio estadio = estadioDAO.buscaPorId(id);
        if (estadio == null) {
            System.out.println("Estádio não encontrado.");
            return;
        }

        List<Cidade> cidades = cidadeDAO.buscarTodos();

        System.out.print("Digite o novo nome do estádio: ");
        String nome = scanner.nextLine();

        System.out.print("Digite a nova capacidade do estádio: ");
        int capacidade = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        System.out.println("Escolha o novo ID da cidade da lista:");
        for (Cidade cidade : cidades) {
            System.out.println(cidade.getIdCidade() + ". " + cidade.getNome());
        }
        System.out.print("ID da cidade: ");
        int idCidade = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        estadio.setNome(nome);
        estadio.setCapacidade(capacidade);
        estadio.setIdCidade(idCidade);

        estadioDAO.atualizar(estadio);
        System.out.println("Estádio atualizado com sucesso!");
    }

    private void removerEstadio() {

        List<Estadio> estadios = estadioDAO.buscarTodos();
        if (estadios.isEmpty()) {
            System.out.println("Nenhum estádio encontrado.");
            return;
        }

        System.out.print("Digite o ID do estádio que deseja remover: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        estadioDAO.eliminar(id);
        System.out.println("Estádio removido com sucesso!");
    }
}
