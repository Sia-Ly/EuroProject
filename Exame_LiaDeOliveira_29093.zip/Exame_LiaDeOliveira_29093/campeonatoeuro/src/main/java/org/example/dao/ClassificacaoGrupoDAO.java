package org.example.dao;

import org.example.config.GerenciadorConexaoBD;
import org.example.modelos.ClassificacaoGrupo;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ClassificacaoGrupoDAO implements IDAO<ClassificacaoGrupo> {

    private final GerenciadorConexaoBD gerenciadorConexao;

    public ClassificacaoGrupoDAO() {
        this.gerenciadorConexao = new GerenciadorConexaoBD();
    }

    @Override
    public void inserir(ClassificacaoGrupo classificacaoGrupo) {
        String sql = "INSERT INTO classificacaoGrupo (idClassificacaoGrupo, idGrupo, idSelecao, pontos, jogos, vitorias, empates, derrotas, golosMarcados, golosSofridos) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, classificacaoGrupo.getIdClassificacaoGrupo());
            statement.setInt(2, classificacaoGrupo.getIdGrupo());
            statement.setInt(3, classificacaoGrupo.getIdSelecao());
            statement.setInt(4, classificacaoGrupo.getPontos());
            statement.setInt(5, classificacaoGrupo.getJogos());
            statement.setInt(6, classificacaoGrupo.getVitorias());
            statement.setInt(7, classificacaoGrupo.getEmpates());
            statement.setInt(8, classificacaoGrupo.getDerrotas());
            statement.setInt(9, classificacaoGrupo.getGolosMarcados());
            statement.setInt(10, classificacaoGrupo.getGolosSofridos());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public ClassificacaoGrupo buscaPorId(int id) {
        String sql = "SELECT * FROM classificacaoGrupo WHERE idClassificacaoGrupo = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return extractClassificacaoGrupoFromResultSet(resultSet);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<ClassificacaoGrupo> buscarTodos() {
        List<ClassificacaoGrupo> classificacoes = new ArrayList<>();
        String sql = "SELECT * FROM classificacaoGrupo";
        try (Connection connection = gerenciadorConexao.obterConexao();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {
            while (resultSet.next()) {
                classificacoes.add(extractClassificacaoGrupoFromResultSet(resultSet));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return classificacoes;
    }

    @Override
    public void atualizar(ClassificacaoGrupo classificacaoGrupo) {
        String sql = "UPDATE classificacaoGrupo SET idGrupo = ?, idSelecao = ?, pontos = ?, jogos = ?, vitorias = ?, empates = ?, derrotas = ?, golosMarcados = ?, golosSofridos = ? " +
                "WHERE idClassificacaoGrupo = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, classificacaoGrupo.getIdGrupo());
            statement.setInt(2, classificacaoGrupo.getIdSelecao());
            statement.setInt(3, classificacaoGrupo.getPontos());
            statement.setInt(4, classificacaoGrupo.getJogos());
            statement.setInt(5, classificacaoGrupo.getVitorias());
            statement.setInt(6, classificacaoGrupo.getEmpates());
            statement.setInt(7, classificacaoGrupo.getDerrotas());
            statement.setInt(8, classificacaoGrupo.getGolosMarcados());
            statement.setInt(9, classificacaoGrupo.getGolosSofridos());
            statement.setInt(10, classificacaoGrupo.getIdClassificacaoGrupo());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void eliminar(int id) {
        String sql = "DELETE FROM classificacaoGrupo WHERE idClassificacaoGrupo = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private ClassificacaoGrupo extractClassificacaoGrupoFromResultSet(ResultSet resultSet) throws SQLException {
        ClassificacaoGrupo classificacaoGrupo = new ClassificacaoGrupo();
        classificacaoGrupo.setIdClassificacaoGrupo(resultSet.getInt("idClassificacaoGrupo"));
        classificacaoGrupo.setIdGrupo(resultSet.getInt("idGrupo"));
        classificacaoGrupo.setIdSelecao(resultSet.getInt("idSelecao"));
        classificacaoGrupo.setPontos(resultSet.getInt("pontos"));
        classificacaoGrupo.setJogos(resultSet.getInt("jogos"));
        classificacaoGrupo.setVitorias(resultSet.getInt("vitorias"));
        classificacaoGrupo.setEmpates(resultSet.getInt("empates"));
        classificacaoGrupo.setDerrotas(resultSet.getInt("derrotas"));
        classificacaoGrupo.setGolosMarcados(resultSet.getInt("golosMarcados"));
        classificacaoGrupo.setGolosSofridos(resultSet.getInt("golosSofridos"));
        return classificacaoGrupo;
    }
}
