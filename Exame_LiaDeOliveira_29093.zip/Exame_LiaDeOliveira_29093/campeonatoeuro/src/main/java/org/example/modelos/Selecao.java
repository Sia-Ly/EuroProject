package org.example.modelos;

public class Selecao {
    private int idSelecao;
    private String nome;
    private int idPais;

    // Construtor vazio
    public Selecao() {}

    // Construtor com parâmetros
    public Selecao(int idSelecao, String nome, int idPais) {
        this.idSelecao = idSelecao;
        this.nome = nome;
        this.idPais = idPais;
    }

    public int getIdSelecao() {
        return idSelecao;
    }

    public void setIdSelecao(int idSelecao) {
        this.idSelecao = idSelecao;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdPais() {
        return idPais;
    }

    public void setIdPais(int paisId) {
        this.idPais = paisId;
    }

    @Override
    public String toString() {
        return "Selecao{" +
                "idSelecao=" + idSelecao +
                ", nome='" + nome + '\'' +
                ", paisId=" + idPais +
                '}';
    }
}
