package org.example.dao;

import org.example.config.GerenciadorConexaoBD;
import org.example.modelos.ClassificacaoFase;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ClassificacaoFaseDAO implements IDAO<ClassificacaoFase>{

    private final GerenciadorConexaoBD gerenciadorConexao;

    public ClassificacaoFaseDAO() {
        this.gerenciadorConexao = new GerenciadorConexaoBD();
    }

    @Override
    public void inserir(ClassificacaoFase classificacaoFase) {
        String sql = "INSERT INTO classificacaoFase (idFase, idSelecao, posicao) " +
                "VALUES (?, ?, ?)";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            statement.setInt(1, classificacaoFase.getIdFase());
            statement.setInt(2, classificacaoFase.getIdSelecao());
            statement.setInt(3, classificacaoFase.getPosicao());
            statement.executeUpdate();

            ResultSet generatedKeys = statement.getGeneratedKeys();
            if (generatedKeys.next()) {
                classificacaoFase.setIdClassificacaoFase(generatedKeys.getInt(1));
            } else {
                throw new SQLException("Falha ao obter o ID da classificação de fase após inserção.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public ClassificacaoFase buscaPorId(int id) {
        String sql = "SELECT * FROM classificacaoFase WHERE idClassificacaoFase = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return extractClassificacaoFaseFromResultSet(resultSet);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<ClassificacaoFase> buscarTodos() {
        List<ClassificacaoFase> classificacoes = new ArrayList<>();
        String sql = "SELECT * FROM classificacaoFase";
        try (Connection connection = gerenciadorConexao.obterConexao();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {
            while (resultSet.next()) {
                classificacoes.add(extractClassificacaoFaseFromResultSet(resultSet));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return classificacoes;
    }

    @Override
    public void atualizar(ClassificacaoFase classificacaoFase) {
        String sql = "UPDATE classificacaoFase SET idFase = ?, idSelecao = ?, posicao = ? " +
                "WHERE idClassificacaoFase = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, classificacaoFase.getIdFase());
            statement.setInt(2, classificacaoFase.getIdSelecao());
            statement.setInt(3, classificacaoFase.getPosicao());
            statement.setInt(4, classificacaoFase.getIdClassificacaoFase());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void eliminar(int id) {
        String sql = "DELETE FROM classificacaoFase WHERE idClassificacaoFase = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private ClassificacaoFase extractClassificacaoFaseFromResultSet(ResultSet resultSet) throws SQLException {
        ClassificacaoFase classificacaoFase = new ClassificacaoFase();
        classificacaoFase.setIdClassificacaoFase(resultSet.getInt("idClassificacaoFase"));
        classificacaoFase.setIdFase(resultSet.getInt("idFase"));
        classificacaoFase.setIdSelecao(resultSet.getInt("idSelecao"));
        classificacaoFase.setPosicao(resultSet.getInt("posicao"));
        return classificacaoFase;
    }
}
