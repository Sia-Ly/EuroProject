package org.example.gestao;

import org.example.dao.JogadorDAO;
import org.example.modelos.Jogador;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;
import java.util.Scanner;

public class GestaoJogador {
    private final JogadorDAO jogadorDao;
    private final Scanner scanner;

    public GestaoJogador() {
        this.jogadorDao = new JogadorDAO();
        this.scanner = new Scanner(System.in);
    }

    public void menu() {
        int opcao;
        do {
            System.out.println("Menu de Gestão de Jogadores");
            System.out.println("1. Criar Jogador");
            System.out.println("2. Atualizar Jogador");
            System.out.println("3. Deletar Jogador");
            System.out.println("4. Listar Jogadores");
            System.out.println("0. Voltar ao Menu Principal");

            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (opcao) {
                case 1 -> criarJogador();
                case 2 -> atualizarJogador();
                case 3 -> deletarJogador();
                case 4 -> listarJogadores();
                case 0 -> System.out.println("Voltando ao Menu Principal...");
                default -> System.out.println("Opção inválida! Tente novamente.");
            }
        } while (opcao != 0);
    }

    private void criarJogador() {
        System.out.print("Nome: ");
        String nome = scanner.nextLine();
        System.out.print("Data de Nascimento (yyyy-mm-dd hh:mm:ss): ");
        Timestamp dataNascimento = Timestamp.valueOf(scanner.nextLine());
        System.out.print("Posição: ");
        String posicao = scanner.nextLine();
        System.out.print("ID da Seleção: ");
        int idSelecao = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        Jogador jogador = new Jogador(0, nome, dataNascimento, posicao, idSelecao);

        jogadorDao.inserir(jogador);
        System.out.println("Jogador criado com sucesso!");
    }

    private void atualizarJogador() {
        System.out.print("ID do Jogador a ser atualizado: ");
        int idJogador = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        Jogador jogador = jogadorDao.buscaPorId(idJogador);
        if (jogador == null) {
            System.out.println("Jogador não encontrado!");
            return;
        }

        System.out.print("Nome (" + jogador.getNome() + "): ");
        String nome = scanner.nextLine();
        if (!nome.isEmpty()) jogador.setNome(nome);

        System.out.print("Data de Nascimento (" + jogador.getDataNascimento() + ") (yyyy-mm-dd hh:mm:ss): ");
        String dataNascimentoStr = scanner.nextLine();
        if (!dataNascimentoStr.isEmpty()) jogador.setDataNascimento(Timestamp.valueOf(dataNascimentoStr));

        System.out.print("Posição (" + jogador.getPosicao() + "): ");
        String posicao = scanner.nextLine();
        if (!posicao.isEmpty()) jogador.setPosicao(posicao);

        System.out.print("ID da Seleção (" + jogador.getIdSelecao() + "): ");
        String idSelecaoStr = scanner.nextLine();
        if (!idSelecaoStr.isEmpty()) jogador.setIdSelecao(Integer.parseInt(idSelecaoStr));

        jogadorDao.atualizar(jogador);
        System.out.println("Jogador atualizado com sucesso!");

    }

    private void deletarJogador() {
        System.out.print("ID do Jogador a ser deletado: ");
        int idJogador = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        jogadorDao.eliminar(idJogador);
        System.out.println("Jogador deletado com sucesso!");
    }

    private void listarJogadores() {
        List<Jogador> jogadores = jogadorDao.buscarTodos();
        if (jogadores.isEmpty()) {
            System.out.println("Nenhum jogador encontrado.");
        } else {
            jogadores.forEach(jogador -> System.out.println(jogador.toString()));
        }
    }
}
