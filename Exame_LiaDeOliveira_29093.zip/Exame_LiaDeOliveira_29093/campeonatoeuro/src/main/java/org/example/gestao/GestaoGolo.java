package org.example.gestao;

import org.example.dao.GoloDAO;
import org.example.dao.JogadorDAO;
import org.example.dao.JogoDAO;
import org.example.modelos.Golo;
import org.example.modelos.Jogador;
import org.example.modelos.Jogo;

import java.util.List;
import java.util.Scanner;

public class GestaoGolo {
    private final GoloDAO goloDAO;
    private final JogadorDAO jogadorDAO;
    private final JogoDAO jogoDAO;
    private final Scanner scanner;

    public GestaoGolo() {
        this.goloDAO = new GoloDAO();
        this.jogadorDAO = new JogadorDAO();
        this.jogoDAO = new JogoDAO();
        this.scanner = new Scanner(System.in);
    }

    public void menu() {
        int opcao;
        do {
            System.out.println("Gestão de Golos");
            System.out.println("1. Adicionar Golo");
            System.out.println("2. Listar Golos");
            System.out.println("3. Atualizar Golo");
            System.out.println("4. Remover Golo");
            System.out.println("5. Voltar ao Menu Principal");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (opcao) {
                case 1 -> adicionarGolo();
                case 2 -> listarGolos();
                case 3 -> atualizarGolo();
                case 4 -> removerGolo();
                case 5 -> System.out.println("Voltando ao Menu Principal...");
                default -> System.out.println("Opção inválida! Tente novamente.");
            }
        } while (opcao != 5);
    }

    private void adicionarGolo() {
        List<Jogador> jogadores = jogadorDAO.buscarTodos();
        if (jogadores.isEmpty()) {
            System.out.println("Nenhum jogador encontrado. Adicione jogadores primeiro.");
            return;
        }

        List<Jogo> jogos = jogoDAO.buscarTodos();
        if (jogos.isEmpty()) {
            System.out.println("Nenhum jogo encontrado. Adicione jogos primeiro.");
            return;
        }

        System.out.println("Escolha o ID do jogo da lista:");
        for (Jogo jogo : jogos) {
            System.out.println(jogo.getIdJogo() + ". " + jogo);
        }
        System.out.print("ID do jogo: ");
        int idJogo = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        System.out.println("Escolha o ID do jogador marcador da lista:");
        for (Jogador jogador : jogadores) {
            System.out.println(jogador.getIdJogador() + ". " + jogador.getNome());
        }
        System.out.print("ID do jogador marcador: ");
        int marcadorId = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        System.out.println("Escolha o ID do jogador assistente da lista (0 se não houver):");
        for (Jogador jogador : jogadores) {
            System.out.println(jogador.getIdJogador() + ". " + jogador.getNome());
        }
        System.out.print("ID do jogador assistente: ");
        int assistenciaId = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        System.out.print("Digite o minuto do golo: ");
        int minuto = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        System.out.print("Foi um penalti? (true/false): ");
        boolean penalti = scanner.nextBoolean();
        scanner.nextLine();  // Consume newline

        System.out.print("Foi um golo na própria baliza? (true/false): ");
        boolean goloPropria = scanner.nextBoolean();
        scanner.nextLine();  // Consume newline

        Golo golo = new Golo();
        golo.setIdJogo(idJogo);
        golo.setMarcadorId(marcadorId);
        golo.setAssistenciaId(assistenciaId);
        golo.setMinuto(minuto);
        golo.setPenalti(penalti);
        golo.setGoloPropria(goloPropria);

        goloDAO.inserir(golo);
        System.out.println("Golo adicionado com sucesso!");
    }

    private void listarGolos() {
        List<Golo> golos = goloDAO.buscarTodos();
        if (golos.isEmpty()) {
            System.out.println("Nenhum golo encontrado.");
        } else {
            System.out.println("Lista de Golos:");
            for (Golo golo : golos) {
                System.out.println(golo);
            }
        }
    }

    private void atualizarGolo() {
        System.out.print("Digite o ID do golo que deseja atualizar: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        Golo golo = goloDAO.buscaPorId(id);
        if (golo == null) {
            System.out.println("Golo não encontrado.");
            return;
        }

        List<Jogador> jogadores = jogadorDAO.buscarTodos();
        List<Jogo> jogos = jogoDAO.buscarTodos();

        System.out.println("Escolha o ID do jogo da lista:");
        for (Jogo jogo : jogos) {
            System.out.println(jogo.getIdJogo() + ". " + jogo);
        }
        System.out.print("ID do jogo: ");
        int idJogo = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        System.out.println("Escolha o ID do jogador marcador da lista:");
        for (Jogador jogador : jogadores) {
            System.out.println(jogador.getIdJogador() + ". " + jogador.getNome());
        }
        System.out.print("ID do jogador marcador: ");
        int marcadorId = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        System.out.println("Escolha o ID do jogador assistente da lista (0 se não houver):");
        for (Jogador jogador : jogadores) {
            System.out.println(jogador.getIdJogador() + ". " + jogador.getNome());
        }
        System.out.print("ID do jogador assistente: ");
        int assistenciaId = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        System.out.print("Digite o minuto do golo: ");
        int minuto = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        System.out.print("Foi um penalti? (true/false): ");
        boolean penalti = scanner.nextBoolean();
        scanner.nextLine();  // Consume newline

        System.out.print("Foi um golo na própria baliza? (true/false): ");
        boolean goloPropria = scanner.nextBoolean();
        scanner.nextLine();  // Consume newline

        golo.setIdJogo(idJogo);
        golo.setMarcadorId(marcadorId);
        golo.setAssistenciaId(assistenciaId);
        golo.setMinuto(minuto);
        golo.setPenalti(penalti);
        golo.setGoloPropria(goloPropria);

        goloDAO.atualizar(golo);
        System.out.println("Golo atualizado com sucesso!");
    }

    private void removerGolo() {
        List<Golo> golos = goloDAO.buscarTodos();
        if (golos.isEmpty()) {
            System.out.println("Nenhum golo encontrado.");
            return;
        }
        for (int i = 0; i < golos.size(); i++) {
            System.out.println((i + 1) + ". " + golos.get(i));
        }
        System.out.print("Digite o ID do golo que deseja remover: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        goloDAO.eliminar(id);
        System.out.println("Golo removido com sucesso!");
    }
}
