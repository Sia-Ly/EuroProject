package org.example.modelos;

public class Fase {
    private int idFase;
    private String nome;

    // Construtor vazio
    public Fase() {}

    // Construtor com parâmetros
    public Fase(int idFase, String nome) {
        this.idFase = idFase;
        this.nome = nome;
    }

    public int getIdFase() {
        return idFase;
    }

    public int setIdFase(int idFase) {
        this.idFase = idFase;
        return idFase;
    }

    public String getNome() {
        return nome;
    }

    public String setNome(String nome) {
        this.nome = nome;
        return nome;
    }

    @Override
    public String toString() {
        return "Fase{" +
                "idFase=" + idFase +
                ", nome='" + nome + '\'' +
                '}';
    }
}

