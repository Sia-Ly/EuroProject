package org.example.constantes;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import static java.lang.System.getenv;

public class ConstantesBD {
    public static final String USUARIO;
    public static final String SENHA;
    public static final String PORTA;
    public static final String NOME_BD;
    public static final String TIPO_DB;
    public static final String HOST;

    static {
        Properties prop = new Properties();
        try (InputStream input = ConstantesBD.class.getClassLoader().getResourceAsStream("config.properties")) {
            prop.load(input);
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        USUARIO = prop.getProperty("USUARIO");
        SENHA = prop.getProperty("SENHA");
        HOST = prop.getProperty("HOST");
        NOME_BD = prop.getProperty("NOMEBD");
        PORTA = prop.getProperty("PORTA");
        TIPO_DB = prop.getProperty("TIPO");
    }
}
