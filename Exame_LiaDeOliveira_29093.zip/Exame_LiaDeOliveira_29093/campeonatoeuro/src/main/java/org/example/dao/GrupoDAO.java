package org.example.dao;

import org.example.config.GerenciadorConexaoBD;
import org.example.modelos.Grupo;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class GrupoDAO implements IDAO<Grupo>{

    private final GerenciadorConexaoBD gerenciadorConexao;

    public GrupoDAO() {
        this.gerenciadorConexao = new GerenciadorConexaoBD();
    }

    public void inserir(Grupo grupo) {
        String sql = "INSERT INTO grupo (idGrupo, nome, idFase) VALUES (?, ?, ?)";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, grupo.getIdGrupo());
            statement.setString(2, grupo.getNome());
            statement.setInt(3, grupo.getIdFase());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Grupo buscaPorId(int id) {
        String sql = "SELECT * FROM grupo WHERE idGrupo = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return extractGrupoFromResultSet(resultSet);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Grupo> buscarTodos() {
        List<Grupo> grupos = new ArrayList<>();
        String sql = "SELECT * FROM grupo";
        try (Connection connection = gerenciadorConexao.obterConexao();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {
            while (resultSet.next()) {
                grupos.add(extractGrupoFromResultSet(resultSet));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return grupos;
    }

    public void atualizar(Grupo grupo) {
        String sql = "UPDATE grupo SET nome = ?, idFase = ? WHERE idGrupo = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, grupo.getNome());
            statement.setInt(2, grupo.getIdFase());
            statement.setInt(3, grupo.getIdGrupo());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void eliminar(int id) {
        String sql = "DELETE FROM grupo WHERE idGrupo = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private Grupo extractGrupoFromResultSet(ResultSet resultSet) throws SQLException {
        Grupo grupo = new Grupo();
        grupo.setIdGrupo(resultSet.getInt("idGrupo"));
        grupo.setNome(resultSet.getString("nome"));
        grupo.setIdFase(resultSet.getInt("idFase"));
        return grupo;
    }
}
