package org.example.gestao;

import org.example.dao.JogoDAO;
import org.example.dao.SelecaoDAO;
import org.example.modelos.Jogo;
import org.example.modelos.Selecao;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;
import java.util.Scanner;

public class GestaoJogo {
    private final JogoDAO jogoDAO;
    private final SelecaoDAO selecaoDAO;
    private final Scanner scanner;

    public GestaoJogo() {
        this.jogoDAO = new JogoDAO();
        this.selecaoDAO = new SelecaoDAO();
        this.scanner = new Scanner(System.in);
    }

    public void menu() {
        int opcao;
        do {
            System.out.println("Gestão de Jogos");
            System.out.println("1. Adicionar Jogo");
            System.out.println("2. Listar Jogos");
            System.out.println("3. Atualizar Jogo");
            System.out.println("4. Remover Jogo");
            System.out.println("5. Voltar ao Menu Principal");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (opcao) {
                case 1 -> adicionarJogo();
                case 2 -> listarJogos();
                case 3 -> atualizarJogo();
                case 4 -> removerJogo();
                case 5 -> System.out.println("Voltando ao Menu Principal...");
                default -> System.out.println("Opção inválida! Tente novamente.");
            }
        } while (opcao != 5);
    }

    private void adicionarJogo() {
        try {
            List<Selecao> selecoes = selecaoDAO.buscarTodos();
            if (selecoes.isEmpty()) {
                System.out.println("Nenhuma seleção encontrada. Adicione seleções primeiro.");
                return;
            }

            System.out.println("Selecione a seleção local:");
            for (int i = 0; i < selecoes.size(); i++) {
                System.out.println((i + 1) + ". " + selecoes.get(i).getNome());
            }
            int escolhaSelecaoLocal = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            Selecao selecaoLocal = selecoes.get(escolhaSelecaoLocal - 1);

            System.out.println("Selecione a seleção visitante:");
            for (int i = 0; i < selecoes.size(); i++) {
                System.out.println((i + 1) + ". " + selecoes.get(i).getNome());
            }
            int escolhaSelecaoVisitante = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            Selecao selecaoVisitante = selecoes.get(escolhaSelecaoVisitante - 1);

            if (selecaoLocal.getIdSelecao() == selecaoVisitante.getIdSelecao()) {
                System.out.println("Seleções devem ser diferentes.");
                return;
            }

            Jogo jogo = new Jogo();
            jogo.setIdSelecaoLocal(selecaoLocal.getIdSelecao());
            jogo.setIdSelecaoVisitante(selecaoVisitante.getIdSelecao());

            System.out.print("Digite a data e hora do jogo (YYYY-MM-DD HH:MM:SS): ");
            String dataHora = scanner.nextLine();
            jogo.setDataHora(Timestamp.valueOf(dataHora));

            System.out.print("Digite o ID do estádio: ");
            int idEstadio = scanner.nextInt();
            scanner.nextLine();  // Consume newline
            jogo.setIdEstadio(idEstadio);

            System.out.print("Digite o ID da fase: ");
            int idFase = scanner.nextInt();
            scanner.nextLine();  // Consume newline
            jogo.setIdFase(idFase);

            System.out.print("Digite o ID do grupo: ");
            int idGrupo = scanner.nextInt();
            scanner.nextLine();  // Consume newline
            jogo.setIdGrupo(idGrupo);

            System.out.print("Digite os gols da seleção local: ");
            int golsLocal = scanner.nextInt();
            scanner.nextLine();  // Consume newline
            jogo.setGolsLocal(golsLocal);

            System.out.print("Digite os gols da seleção visitante: ");
            int golsVisitante = scanner.nextInt();
            scanner.nextLine();  // Consume newline
            jogo.setGolsVisitante(golsVisitante);

            jogoDAO.inserir(jogo);
            System.out.println("Jogo adicionado com sucesso!");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void listarJogos() {
        List<Jogo> jogos = jogoDAO.buscarTodos();
        if (jogos.isEmpty()) {
            System.out.println("Nenhum jogo encontrado.");
        } else {
            for (Jogo jogo : jogos) {
                System.out.println(jogo);
            }
        }
    }

    private void atualizarJogo() {
        System.out.print("Digite o ID do jogo que deseja atualizar: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        Jogo jogo = jogoDAO.buscaPorId(id);
        if (jogo == null) {
            System.out.println("Jogo não encontrado.");
            return;
        }

        System.out.print("Digite a nova data e hora do jogo (YYYY-MM-DD HH:MM:SS): ");
        String dataHora = scanner.nextLine();
        jogo.setDataHora(Timestamp.valueOf(dataHora));

        System.out.print("Digite o novo ID do estádio: ");
        int idEstadio = scanner.nextInt();
        scanner.nextLine();  // Consume newline
        jogo.setIdEstadio(idEstadio);

        System.out.print("Digite o novo ID da fase: ");
        int idFase = scanner.nextInt();
        scanner.nextLine();  // Consume newline
        jogo.setIdFase(idFase);

        System.out.print("Digite o novo ID do grupo: ");
        int idGrupo = scanner.nextInt();
        scanner.nextLine();  // Consume newline
        jogo.setIdGrupo(idGrupo);

        System.out.print("Digite os novos gols da seleção local: ");
        int golsLocal = scanner.nextInt();
        scanner.nextLine();  // Consume newline
        jogo.setGolsLocal(golsLocal);

        System.out.print("Digite os novos gols da seleção visitante: ");
        int golsVisitante = scanner.nextInt();
        scanner.nextLine();  // Consume newline
        jogo.setGolsVisitante(golsVisitante);

        jogoDAO.atualizar(jogo);
        System.out.println("Jogo atualizado com sucesso!");
    }

    private void removerJogo() {
        System.out.print("Digite o ID do jogo que deseja remover: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        jogoDAO.eliminar(id);
        System.out.println("Jogo removido com sucesso!");
    }
}
