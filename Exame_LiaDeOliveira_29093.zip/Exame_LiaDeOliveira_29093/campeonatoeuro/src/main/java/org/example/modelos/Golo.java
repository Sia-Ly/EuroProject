package org.example.modelos;

public class Golo {
    private int idGolo;
    private int idJogo;
    private int marcadorId;
    private int assistenciaId;
    private int minuto;
    private boolean penalti;
    private boolean goloPropria;

    // Construtor vazio
    public Golo() {}

    // Construtor com parâmetros
    public Golo(int idGolo, int idJogo, int marcadorId, int assistenciaId, int minuto, boolean penalti, boolean goloPropria) {
        this.idGolo = idGolo;
        this.idJogo = idJogo;
        this.marcadorId = marcadorId;
        this.assistenciaId = assistenciaId;
        this.minuto = minuto;
        this.penalti = penalti;
        this.goloPropria = goloPropria;
    }

    public int getIdGolo() {
        return idGolo;
    }

    public void setIdGolo(int idGolo) {
        this.idGolo = idGolo;
    }

    public int getIdJogo() {
        return idJogo;
    }

    public void setIdJogo(int idJogo) {
        this.idJogo = idJogo;
    }

    public int getMarcadorId() {
        return marcadorId;
    }

    public void setMarcadorId(int marcadorId) {
        this.marcadorId = marcadorId;
    }

    public int getAssistenciaId() {
        return assistenciaId;
    }

    public void setAssistenciaId(int assistenciaId) {
        this.assistenciaId = assistenciaId;
    }

    public int getMinuto() {
        return minuto;
    }

    public void setMinuto(int minuto) {
        this.minuto = minuto;
    }

    public boolean isPenalti() {
        return penalti;
    }

    public void setPenalti(boolean penalti) {
        this.penalti = penalti;
    }

    public boolean isGoloPropria() {
        return goloPropria;
    }

    public void setGoloPropria(boolean goloPropria) {
        this.goloPropria = goloPropria;
    }

    @Override
    public String toString() {
        return "Golo{" +
                "id=" + idGolo +
                ", jogoId=" + idJogo +
                ", marcadorId=" + marcadorId +
                ", assistenciaId=" + assistenciaId +
                ", minuto=" + minuto +
                ", penalti=" + penalti +
                ", goloPropria=" + goloPropria +
                '}';
    }
}
