package org.example.gestao;

import org.example.dao.GrupoDAO;
import org.example.dao.FaseDAO;
import org.example.modelos.Grupo;
import org.example.modelos.Fase;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class GestaoGrupo {
    private final GrupoDAO grupoDAO;
    private final FaseDAO faseDAO;
    private final Scanner scanner;

    public GestaoGrupo() {
        this.grupoDAO = new GrupoDAO();
        this.faseDAO = new FaseDAO();
        this.scanner = new Scanner(System.in);
    }

    public void menu() {
        int opcao;
        do {
            System.out.println("Gestão de Grupos");
            System.out.println("1. Adicionar Grupo");
            System.out.println("2. Listar Grupos");
            System.out.println("3. Atualizar Grupo");
            System.out.println("4. Remover Grupo");
            System.out.println("5. Voltar ao Menu Principal");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (opcao) {
                case 1 -> adicionarGrupo();
                case 2 -> listarGrupos();
                case 3 -> atualizarGrupo();
                case 4 -> removerGrupo();
                case 5 -> System.out.println("Voltando ao Menu Principal...");
                default -> System.out.println("Opção inválida! Tente novamente.");
            }
        } while (opcao != 5);
    }

    private void adicionarGrupo() {
        List<Fase> fases = faseDAO.buscarTodos();
        if (fases.isEmpty()) {
            System.out.println("Nenhuma fase encontrada. Adicione fases primeiro.");
            return;
        }

        System.out.print("Digite o nome do grupo: ");
        String nome = scanner.nextLine();

        System.out.println("Selecione a fase:");
        for (int i = 0; i < fases.size(); i++) {
            System.out.println((i + 1) + ". " + fases.get(i).getNome());
        }
        int faseIndex = scanner.nextInt() - 1;
        scanner.nextLine();  // Consume newline

        if (faseIndex < 0 || faseIndex >= fases.size()) {
            System.out.println("Fase inválida. Operação cancelada.");
            return;
        }

        Grupo grupo = new Grupo();
        grupo.setNome(nome);
        grupo.setIdFase(fases.get(faseIndex).getIdFase());

        grupoDAO.inserir(grupo);
        System.out.println("Grupo adicionado com sucesso!");
    }

    private void listarGrupos() {
        List<Grupo> grupos = grupoDAO.buscarTodos();
        if (grupos.isEmpty()) {
            System.out.println("Nenhum grupo encontrado.");
        } else {
            System.out.println("Lista de Grupos:");
            for (Grupo grupo : grupos) {
                System.out.println("ID: " + grupo.getIdGrupo() + ", Nome: " + grupo.getNome() + ", ID Fase: " + grupo.getIdFase());
            }
        }
    }

    private void atualizarGrupo() {
        System.out.print("Digite o ID do grupo que deseja atualizar: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        Grupo grupo = grupoDAO.buscaPorId(id);
        if (grupo == null) {
            System.out.println("Grupo não encontrado.");
            return;
        }

        List<Fase> fases = faseDAO.buscarTodos();
        if (fases.isEmpty()) {
            System.out.println("Nenhuma fase encontrada. Adicione fases primeiro.");
            return;
        }

        System.out.print("Digite o novo nome do grupo (atual: " + grupo.getNome() + "): ");
        String nome = scanner.nextLine();

        System.out.println("Selecione a nova fase (atual: " + grupo.getIdFase() + "):");
        for (int i = 0; i < fases.size(); i++) {
            System.out.println((i + 1) + ". " + fases.get(i).getNome());
        }
        int faseIndex = scanner.nextInt() - 1;
        scanner.nextLine();  // Consume newline

        if (faseIndex < 0 || faseIndex >= fases.size()) {
            System.out.println("Fase inválida. Operação cancelada.");
            return;
        }

        grupo.setNome(nome);
        grupo.setIdFase(fases.get(faseIndex).getIdFase());

        grupoDAO.atualizar(grupo);
        System.out.println("Grupo atualizado com sucesso!");
    }

    private void removerGrupo() {
        System.out.print("Digite o ID do grupo que deseja remover: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        grupoDAO.eliminar(id);
        System.out.println("Grupo removido com sucesso!");
    }
}
