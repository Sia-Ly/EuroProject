package org.example.gestao;

import org.example.dao.SubstituicaoDAO;
import org.example.dao.JogadorDAO;
import org.example.dao.JogoDAO;
import org.example.modelos.Substituicao;
import org.example.modelos.Jogador;
import org.example.modelos.Jogo;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class GestaoSubstituicao {
    private final SubstituicaoDAO substituicaoDAO;
    private final JogadorDAO jogadorDAO;
    private final JogoDAO jogoDAO;
    private final Scanner scanner;

    public GestaoSubstituicao() {
        this.substituicaoDAO = new SubstituicaoDAO();
        this.jogadorDAO = new JogadorDAO();
        this.jogoDAO = new JogoDAO();
        this.scanner = new Scanner(System.in);
    }

    public void menu() {
        int opcao;
        do {
            System.out.println("Gestão de Substituições");
            System.out.println("1. Adicionar Substituição");
            System.out.println("2. Listar Substituições");
            System.out.println("3. Atualizar Substituição");
            System.out.println("4. Remover Substituição");
            System.out.println("5. Voltar ao Menu Principal");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (opcao) {
                case 1 -> adicionarSubstituicao();
                case 2 -> listarSubstituicoes();
                case 3 -> atualizarSubstituicao();
                case 4 -> removerSubstituicao();
                case 5 -> System.out.println("Voltando ao Menu Principal...");
                default -> System.out.println("Opção inválida! Tente novamente.");
            }
        } while (opcao != 5);
    }

    private void adicionarSubstituicao() {
        List<Jogador> jogadores = jogadorDAO.buscarTodos();
        if (jogadores.isEmpty()) {
            System.out.println("Nenhum jogador encontrado. Adicione jogadores primeiro.");
            return;
        }

        List<Jogo> jogos = jogoDAO.buscarTodos();
        if (jogos.isEmpty()) {
            System.out.println("Nenhum jogo encontrado. Adicione jogos primeiro.");
            return;
        }

        System.out.println("Selecione o jogador que sairá:");
        for (int i = 0; i < jogadores.size(); i++) {
            System.out.println((i + 1) + ". " + jogadores.get(i).getNome());
        }
        int escolhaJogadorSaida = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        Jogador jogadorSaida = jogadores.get(escolhaJogadorSaida - 1);

        System.out.println("Selecione o jogador que entrará:");
        for (int i = 0; i < jogadores.size(); i++) {
            System.out.println((i + 1) + ". " + jogadores.get(i).getNome());
        }
        int escolhaJogadorEntrada = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        Jogador jogadorEntrada = jogadores.get(escolhaJogadorEntrada - 1);

        System.out.println("Selecione o jogo:");
        for (int i = 0; i < jogos.size(); i++) {
            System.out.println((i + 1) + ". " + jogos.get(i).getIdJogo());
        }
        int escolhaJogo = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        Jogo jogo = jogos.get(escolhaJogo - 1);

        System.out.print("Digite o minuto da substituição: ");
        int minuto = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        Substituicao substituicao = new Substituicao();
        substituicao.setIdJogadorSaiu(jogadorSaida.getIdJogador());
        substituicao.setIdJogadorEntrou(jogadorEntrada.getIdJogador());
        substituicao.setIdJogo(jogo.getIdJogo());
        substituicao.setMinuto(minuto);

        substituicaoDAO.inserir(substituicao);
        System.out.println("Substituição adicionada com sucesso!");

    }

    private void listarSubstituicoes() {
        List<Substituicao> substituicoes = substituicaoDAO.buscarTodos();
        if (substituicoes.isEmpty()) {
            System.out.println("Nenhuma substituição encontrada.");
        } else {
            System.out.println("Lista de Substituições:");
            for (Substituicao substituicao : substituicoes) {
                System.out.println("ID: " + substituicao.getIdSubstituicao() +
                        ", Jogador que saiu: " + substituicao.getIdJogadorSaiu() +
                        ", Jogador que entrou: " + substituicao.getIdJogadorEntrou() +
                        ", Jogo: " + substituicao.getIdJogo() +
                        ", Minuto: " + substituicao.getMinuto());
            }
        }
    }

    private void atualizarSubstituicao() {
        List<Substituicao> substituicoes = substituicaoDAO.buscarTodos();
        if(substituicoes.isEmpty()){
            System.out.println("Nenhuma subisticuicao");
            return;
        }
        System.out.print("Digite o ID da substituição que deseja atualizar: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        Substituicao substituicao = substituicaoDAO.buscaPorId(id);
        if (substituicao == null) {
            System.out.println("Substituição não encontrada.");
            return;
        }

        List<Jogador> jogadores = jogadorDAO.buscarTodos();
        if (!jogadores.isEmpty()) {
            System.out.println("Selecione o novo jogador que sairá:");
            for (int i = 0; i < jogadores.size(); i++) {
                System.out.println((i + 1) + ". " + jogadores.get(i).getNome());
            }
            int escolhaJogadorSaida = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            Jogador jogadorSaida = jogadores.get(escolhaJogadorSaida - 1);
            substituicao.setIdJogadorSaiu(jogadorSaida.getIdJogador());
        }

        if (!jogadores.isEmpty()) {
            System.out.println("Selecione o novo jogador que entrará:");
            for (int i = 0; i < jogadores.size(); i++) {
                System.out.println((i + 1) + ". " + jogadores.get(i).getNome());
            }
            int escolhaJogadorEntrada = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            Jogador jogadorEntrada = jogadores.get(escolhaJogadorEntrada - 1);
            substituicao.setIdJogadorEntrou(jogadorEntrada.getIdJogador());
        }

        List<Jogo> jogos = jogoDAO.buscarTodos();
        if (!jogos.isEmpty()) {
            System.out.println("Selecione o novo jogo:");
            for (int i = 0; i < jogos.size(); i++) {
                System.out.println((i + 1) + ". " + jogos.get(i).getIdJogo());
            }
            int escolhaJogo = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            Jogo jogo = jogos.get(escolhaJogo - 1);
            substituicao.setIdJogo(jogo.getIdJogo());
        }

        System.out.print("Digite o novo minuto da substituição (atual: " + substituicao.getMinuto() + "): ");
        int minuto = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        substituicao.setMinuto(minuto);
        substituicaoDAO.atualizar(substituicao);
        System.out.println("Substituição atualizada com sucesso!");

    }

    private void removerSubstituicao() {
        List<Substituicao> substituicoes = substituicaoDAO.buscarTodos();
        if (substituicoes.isEmpty()) {
            System.out.println("Nenhuma substituição encontrada.");
            return;
        }
        System.out.print("Digite o ID da substituição que deseja remover: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        substituicaoDAO.eliminar(id);
        System.out.println("Substituição removida com sucesso!");
    }
}
