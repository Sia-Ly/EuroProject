package org.example.gestao;

import org.example.dao.CartaoDAO;
import org.example.dao.JogadorDAO;
import org.example.dao.JogoDAO;
import org.example.modelos.Cartao;
import org.example.modelos.Jogador;
import org.example.modelos.Jogo;


import java.util.List;
import java.util.Scanner;

public class GestaoCartao {
    private final CartaoDAO cartaoDAO;
    private final JogadorDAO jogadorDAO;
    private final JogoDAO jogoDAO;
    private final Scanner scanner;

    public GestaoCartao() {
        this.cartaoDAO = new CartaoDAO();
        this.jogadorDAO = new JogadorDAO();
        this.jogoDAO = new JogoDAO();
        this.scanner = new Scanner(System.in);
    }

    public void menu() {
        int opcao;
        do {
            System.out.println("Gestão de Cartões");
            System.out.println("1. Adicionar Cartão");
            System.out.println("2. Listar Cartões");
            System.out.println("3. Atualizar Cartão");
            System.out.println("4. Remover Cartão");
            System.out.println("5. Voltar ao Menu Principal");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (opcao) {
                case 1 -> adicionarCartao();
                case 2 -> listarCartoes();
                case 3 -> atualizarCartao();
                case 4 -> removerCartao();
                case 5 -> System.out.println("Voltando ao Menu Principal...");
                default -> System.out.println("Opção inválida! Tente novamente.");
            }
        } while (opcao != 5);
    }

    private void adicionarCartao() {
        List<Jogador> jogadores = jogadorDAO.buscarTodos();
        if (jogadores.isEmpty()) {
            System.out.println("Nenhum jogador encontrado. Adicione jogadores primeiro.");
            return;
        }

        List<Jogo> jogos = jogoDAO.buscarTodos();
        if (jogos.isEmpty()) {
            System.out.println("Nenhum jogo encontrado. Adicione jogos primeiro.");
            return;
        }

        System.out.println("Selecione o jogador:");
        for (int i = 0; i < jogadores.size(); i++) {
            System.out.println((i + 1) + ". " + jogadores.get(i).getNome());
        }
        int escolhaJogador = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        Jogador jogadorSelecionado = jogadores.get(escolhaJogador - 1);

        System.out.println("Selecione o jogo:");
        for (int i = 0; i < jogos.size(); i++) {
            System.out.println((i + 1) + ". " + jogos.get(i).getIdJogo());
        }
        int escolhaJogo = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        Jogo jogoSelecionado = jogos.get(escolhaJogo - 1);

        scanner.nextLine();  // Consume newline

        System.out.print("Digite o tipo de cartão (amarelo ou vermelho): ");
        String tipo = scanner.nextLine();

        Cartao cartao = new Cartao();
        cartao.setIdJogador(jogadorSelecionado.getIdJogador());
        cartao.setIdJogo(jogoSelecionado.getIdJogo());
        cartao.setTipo(tipo);

        cartaoDAO.inserir(cartao);
        System.out.println("Cartão adicionado com sucesso!");

    }

    private void listarCartoes() {
        List<Cartao> cartoes = cartaoDAO.buscarTodos();
        if (cartoes.isEmpty()) {
            System.out.println("Nenhum cartão encontrado.");
        } else {
            System.out.println("Lista de Cartões:");
            for (Cartao cartao : cartoes) {
                System.out.println("ID: " + cartao.getIdCartao() + ", Jogador ID: " + cartao.getIdJogador() + ", Jogo ID: " + cartao.getIdJogo() + ", Tipo: " + cartao.getTipo());
            }
        }
    }

    private void atualizarCartao() {
        System.out.print("Digite o ID do cartão que deseja atualizar: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        Cartao cartao = cartaoDAO.buscaPorId(id);
        if (cartao == null) {
            System.out.println("Cartão não encontrado.");
            return;
        }

        List<Jogador> jogadores = jogadorDAO.buscarTodos();
        if (!jogadores.isEmpty()) {
            System.out.println("Selecione o novo jogador:");
            for (int i = 0; i < jogadores.size(); i++) {
                System.out.println((i + 1) + ". " + jogadores.get(i).getNome());
            }
            int escolhaJogador = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            Jogador jogadorSelecionado = jogadores.get(escolhaJogador - 1);
            cartao.setIdJogador(jogadorSelecionado.getIdJogador());
        }

        List<Jogo> jogos = jogoDAO.buscarTodos();
        if (!jogos.isEmpty()) {
            System.out.println("Selecione o novo jogo:");
            for (int i = 0; i < jogos.size(); i++) {
                System.out.println((i + 1) + ". " + jogos.get(i).getIdJogo());
            }
            int escolhaJogo = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            Jogo jogoSelecionado = jogos.get(escolhaJogo - 1);
            cartao.setIdJogo(jogoSelecionado.getIdJogo());
        }

        System.out.print("Digite o novo tipo de cartão (atual: " + cartao.getTipo() + "): ");
        String tipo = scanner.nextLine();

        cartao.setTipo(tipo);
        cartaoDAO.atualizar(cartao);
        System.out.println("Cartão atualizado com sucesso!");

    }

    private void removerCartao() {
        System.out.print("Digite o ID do cartão que deseja remover: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        cartaoDAO.eliminar(id);
        System.out.println("Cartão removido com sucesso!");
    }
}
