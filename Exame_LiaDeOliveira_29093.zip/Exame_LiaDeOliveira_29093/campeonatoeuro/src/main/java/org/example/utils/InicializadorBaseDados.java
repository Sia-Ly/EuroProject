package org.example.utils;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.example.config.GerenciadorConexaoBD;

public class InicializadorBaseDados {

    private final GerenciadorConexaoBD gerenciadorConexaoBD;

    public InicializadorBaseDados(GerenciadorConexaoBD gerenciadorConexaoBD) {
        this.gerenciadorConexaoBD = gerenciadorConexaoBD;
    }

    public boolean databaseExists(String dbName) throws SQLException {
        try (Connection connection = gerenciadorConexaoBD.getConnectionToDefaultDb()) {
            DatabaseMetaData metaData = connection.getMetaData();
            try (ResultSet rs = metaData.getCatalogs()) {
                while (rs.next()) {
                    String databaseName = rs.getString(1);
                    if (databaseName.equals(dbName)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public void initializeDatabase() {
        Connection defaultConnection = null;
        Statement defaultStatement = null;

        try {
            defaultConnection = gerenciadorConexaoBD.getConnectionToDefaultDb();
            defaultStatement = defaultConnection.createStatement();

            if (!databaseExists("euro")) {
                defaultStatement.executeUpdate("CREATE DATABASE euro");
                System.out.println("DB criada com sucesso.");
            } else {
                System.out.println("DB já existe.");
            }

        } catch (SQLException e) {
            System.out.println("Erro ao verificar/criar a DB " + e);
        } finally {
            try {
                if (defaultStatement != null) defaultStatement.close();
                if (defaultConnection != null) defaultConnection.close();
            } catch (SQLException e) {
                System.out.println("Erro ao fechar a conexão com o banco de dados padrão " + e);
            }
        }

        Connection europeufutebolConnection = null;
        Statement europeufutebolStatement = null;

        try {
            europeufutebolConnection = gerenciadorConexaoBD.obterConexao();
            europeufutebolStatement = europeufutebolConnection.createStatement();

            DatabaseMetaData dmd = europeufutebolConnection.getMetaData();
            ResultSet tables = dmd.getTables(null, null, "pais", null);

            if (!tables.next()) {

                String createTablesSQL = """
                    CREATE TABLE pais (
                        idPais SERIAL PRIMARY KEY,
                        nome VARCHAR(100) NOT NULL,
                        codigoIso VARCHAR(3) NOT NULL
                    );

                    CREATE TABLE cidade (
                        idCidade SERIAL PRIMARY KEY,
                        nome VARCHAR(100) NOT NULL,
                        idPais INT,
                        FOREIGN KEY (idPais) REFERENCES pais(idPais) ON DELETE CASCADE
                    );

                    CREATE TABLE estadio (
                        idEstadio SERIAL PRIMARY KEY,
                        nome VARCHAR(100) NOT NULL,
                        capacidade INT,
                        idCidade INT,
                        FOREIGN KEY (idCidade) REFERENCES cidade(idCidade) ON DELETE CASCADE
                    );

                    CREATE TABLE selecao (
                        idSelecao SERIAL PRIMARY KEY,
                        nome VARCHAR(100) NOT NULL,
                        idPais INT,
                        FOREIGN KEY (idPais) REFERENCES pais(idPais) ON DELETE CASCADE
                    );

                    CREATE TABLE jogador (
                        idJogador SERIAL PRIMARY KEY,
                        nome VARCHAR(100) NOT NULL,
                        dataNascimento DATE,
                        posicao VARCHAR(50),
                        idSelecao INT,
                        FOREIGN KEY (idSelecao) REFERENCES selecao(idSelecao) ON DELETE CASCADE
                    );

                    CREATE TABLE fase (
                        idFase SERIAL PRIMARY KEY,
                        nome VARCHAR(50) NOT NULL
                    );

                    CREATE TABLE grupo (
                        idGrupo SERIAL PRIMARY KEY,
                        nome VARCHAR(50) NOT NULL,
                        idFase INT,
                        FOREIGN KEY (idFase) REFERENCES fase(idFase) ON DELETE CASCADE
                    );

                    CREATE TABLE IF NOT EXISTS calendario (
                        idCalendario SERIAL PRIMARY KEY,
                        data TIMESTAMP NOT NULL,
                        idFase INT,
                        idEstadio INT,
                        FOREIGN KEY (idFase) REFERENCES fase(idFase) ON DELETE CASCADE,
                        FOREIGN KEY (idEstadio) REFERENCES estadio(idEstadio) ON DELETE CASCADE
                    );

                    CREATE TABLE jogo (
                        idJogo SERIAL PRIMARY KEY,
                        dataHora TIMESTAMP,
                        idEstadio INT,
                        isSelecaoLocal INT,
                        idSelecaoVisitante INT,
                        golsLocal INT DEFAULT 0,
                        golsVisitante INT DEFAULT 0,
                        idGrupo INT,
                        idFase INT,
                        FOREIGN KEY (idEstadio) REFERENCES estadio(idEstadio) ON DELETE CASCADE,
                        FOREIGN KEY (isSelecaoLocal) REFERENCES selecao(idSelecao) ON DELETE CASCADE,
                        FOREIGN KEY (idSelecaoVisitante) REFERENCES selecao(idSelecao) ON DELETE CASCADE,
                        FOREIGN KEY (idGrupo) REFERENCES grupo(idGrupo) ON DELETE CASCADE,
                        FOREIGN KEY (idFase) REFERENCES fase(idFase) ON DELETE CASCADE
                    );

                    CREATE TABLE golo (
                        idGolo SERIAL PRIMARY KEY,
                        idJogo INT,
                        marcador INT,
                        assistente INT,
                        minuto INT,
                        penalti BOOLEAN DEFAULT FALSE,
                        goloPropria BOOLEAN DEFAULT FALSE,
                        FOREIGN KEY (idJogo) REFERENCES jogo(idJogo) ON DELETE CASCADE,
                        FOREIGN KEY (marcador) REFERENCES jogador(idJogador),
                        FOREIGN KEY (assistente) REFERENCES jogador(idJogador)
                    );

                    CREATE TABLE classificacaoGrupo (
                        idClassificacaoGrupo SERIAL PRIMARY KEY,
                        idGrupo INT,
                        idSelecao INT,
                        pontos INT DEFAULT 0,
                        jogos INT DEFAULT 0,
                        vitorias INT DEFAULT 0,
                        empates INT DEFAULT 0,
                        derrotas INT DEFAULT 0,
                        golosMarcados INT DEFAULT 0,
                        golosSofridos INT DEFAULT 0,
                        FOREIGN KEY (idGrupo) REFERENCES grupo(idGrupo) ON DELETE CASCADE,
                        FOREIGN KEY (idSelecao) REFERENCES selecao(idSelecao) ON DELETE CASCADE
                    );

                    CREATE TABLE classificacaoFase (
                        idClassificacaoFase SERIAL PRIMARY KEY,
                        idFase INT,
                        idSelecao INT,
                        posicao INT,
                        FOREIGN KEY (idFase) REFERENCES fase(idFase) ON DELETE CASCADE,
                        FOREIGN KEY (idSelecao) REFERENCES selecao(idSelecao) ON DELETE CASCADE
                    );

                    -- Tabela de Substituições
                    CREATE TABLE substituicao (
                        idSubstituicao SERIAL PRIMARY KEY,
                        idJogo INT,
                        idJogadorSaiu INT,
                        idJogadorEntrou INT,
                        minuto INT,
                        FOREIGN KEY (idJogo) REFERENCES jogo(idJogo) ON DELETE CASCADE,
                        FOREIGN KEY (idJogadorSaiu) REFERENCES jogador(idJogador),
                        FOREIGN KEY (idJogadorEntrou) REFERENCES jogador(idJogador)
                    );

                    -- Tabela de Cartões
                    CREATE TABLE cartao (
                        idCartao SERIAL PRIMARY KEY,
                        idJogo INT,
                        idJogador INT,
                        tipo VARCHAR(8) NOT NULL,
                        minuto INT,
                        FOREIGN KEY (idJogo) REFERENCES jogo(idJogo) ON DELETE CASCADE,
                        FOREIGN KEY (idJogador) REFERENCES jogador(idJogador)
                    );

                    -- Tabela de Estatísticas Globais por Equipe
                    CREATE TABLE estatisticaGlobal (
                        idEstatisticaGlobal SERIAL PRIMARY KEY,
                        idJogo INT,
                        idSelecao INT,
                        remates INT DEFAULT 0,
                        livres INT DEFAULT 0,
                        forasJogo INT DEFAULT 0,
                        FOREIGN KEY (idJogo) REFERENCES jogo(idJogo) ON DELETE CASCADE,
                        FOREIGN KEY (idSelecao) REFERENCES selecao(idSelecao) ON DELETE CASCADE
                    );

                    -- Tabela de Estatísticas Individuais
                    CREATE TABLE estatisticaIndividual (
                        idEstatisticaIndividual SERIAL PRIMARY KEY,
                        idJogador INT,
                        golos INT DEFAULT 0,
                        assistencias INT DEFAULT 0,
                        jogos INT DEFAULT 0,
                        minutosJogados INT DEFAULT 0,
                        cartoesAmarelos INT DEFAULT 0,
                        cartoesVermelhos INT DEFAULT 0,
                        FOREIGN KEY (idJogador) REFERENCES jogador(idJogador) ON DELETE CASCADE
                    );

                    -- Trigger para atualizar estatísticas após inserção de um golo
                    CREATE TRIGGER atualiza_estatisticas_apos_golo
                        AFTER INSERT ON golo
                        FOR EACH ROW
                    BEGIN
                        -- Atualiza estatísticas do marcador
                        INSERT INTO estatisticaIndividual (idJogador, golos)
                        VALUES (NEW.marcador, 1)
                        ON DUPLICATE KEY UPDATE golos = golos + 1;

                        -- Atualiza estatísticas do assistente (se houver)
                        IF NEW.assistente IS NOT NULL THEN
                            INSERT INTO estatisticaIndividual (idJogador, assistencias)
                            VALUES (NEW.assistente, 1)
                            ON DUPLICATE KEY UPDATE assistencias = assistencias + 1;
                        END IF;
                    END;

                    -- Trigger para atualizar estatísticas após inserção de uma substituição
                    CREATE TRIGGER atualiza_estatisticas_apos_substituicao
                        AFTER INSERT ON substituicao
                        FOR EACH ROW
                    BEGIN
                        -- Atualiza jogos para o jogador que entrou
                        UPDATE estatisticaIndividual
                        SET jogos = jogos + 1
                        WHERE idJogador = NEW.idJogadorEntrou;

                        -- Atualiza minutos jogados para o jogador que saiu
                        UPDATE estatisticaIndividual
                        SET minutosJogados = minutosJogados + NEW.minuto
                        WHERE idJogador = NEW.idJogadorSaiu;
                    END;
                """;

                europeufutebolStatement.executeUpdate(createTablesSQL);
                System.out.println("Tabelas criadas com sucesso.");

            } else {
                System.out.println("Tabelas já existem.");
            }

        } catch (SQLException e) {
            System.out.println("Erro ao verificar/criar as tabelas: " + e);
        } finally {
            try {
                if (europeufutebolStatement != null) europeufutebolStatement.close();
                if (europeufutebolConnection != null) europeufutebolConnection.close();
            } catch (SQLException e) {
                System.out.println("Erro ao fechar a conexão com a base de dados europeufutebol: " + e);
            }
        }
    }

}
