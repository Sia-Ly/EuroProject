package org.example.dao;

import org.example.config.GerenciadorConexaoBD;
import org.example.modelos.Calendario;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CalendarioDAO implements IDAO<Calendario> {

    private final GerenciadorConexaoBD gerenciadorConexao;

    public CalendarioDAO() {
        this.gerenciadorConexao = new GerenciadorConexaoBD();
    }

    public void inserir(Calendario calendario) {
        String sql = "INSERT INTO calendario (idCalendario, data, idFase, idEstadio ) VALUES (?, ?, ?, ?)";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, calendario.getIdCalendario());
            statement.setTimestamp(2, new java.sql.Timestamp(calendario.getData().getTime()));
            statement.setInt(3, calendario.getIdFase());
            statement.setInt(3, calendario.getIdEstadio());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void atualizar(Calendario calendario) {
        String sql = "UPDATE calendario SET data = ?, idFase = ?, idEstadio = ? WHERE idCalendario = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setTimestamp(1, new java.sql.Timestamp(calendario.getData().getTime()));
            statement.setInt(2, calendario.getIdFase());
            statement.setInt(3, calendario.getIdEstadio());
            statement.setInt(4, calendario.getIdCalendario());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

            public Calendario buscaPorId(int id) {
        String sql = "SELECT * FROM calendario WHERE idCalendario = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return extractCalendarioFromResultSet(resultSet);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Calendario> buscarTodos() {
        List<Calendario> eventos = new ArrayList<>();
        String sql = "SELECT * FROM calendario";
        try (Connection connection = gerenciadorConexao.obterConexao();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {
            while (resultSet.next()) {
                eventos.add(extractCalendarioFromResultSet(resultSet));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return eventos;
    }

    public void eliminar(int id) {
        String sql = "DELETE FROM calendario WHERE idCalendario = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private Calendario extractCalendarioFromResultSet(ResultSet resultSet) throws SQLException {
        Calendario calendario = new Calendario();
        calendario.setIdCalendario(resultSet.getInt("idCalendario"));
        calendario.setData(resultSet.getTimestamp("data"));
        calendario.setIdFase(resultSet.getInt("idFase"));
        calendario.setIdEstadio(resultSet.getInt("idEstadio"));
        return calendario;
    }
}