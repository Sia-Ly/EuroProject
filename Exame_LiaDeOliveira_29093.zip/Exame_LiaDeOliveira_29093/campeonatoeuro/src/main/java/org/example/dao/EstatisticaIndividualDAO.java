package org.example.dao;

import org.example.config.GerenciadorConexaoBD;
import org.example.modelos.EstatisticaIndividual;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EstatisticaIndividualDAO implements IDAO<EstatisticaIndividual> {

    private final GerenciadorConexaoBD gerenciadorConexao;

    public EstatisticaIndividualDAO() {
        this.gerenciadorConexao = new GerenciadorConexaoBD();
    }

    @Override
    public void inserir(EstatisticaIndividual estatisticaIndividual) {
        String sql = "INSERT INTO estatisticaIndividual (idEstatisticaIndividual, idJogador, golos, assistencias, jogos, minutosJogados, cartoesAmarelos, cartoesVermelhos) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, estatisticaIndividual.getIdEstatisticaIndividual());
            statement.setInt(2, estatisticaIndividual.getIdJogador());
            statement.setInt(3, estatisticaIndividual.getGolos());
            statement.setInt(4, estatisticaIndividual.getAssistencias());
            statement.setInt(5, estatisticaIndividual.getJogos());
            statement.setInt(6, estatisticaIndividual.getMinutosJogados());
            statement.setInt(7, estatisticaIndividual.getCartoesAmarelos());
            statement.setInt(8, estatisticaIndividual.getCartoesVermelhos());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public EstatisticaIndividual buscaPorId(int id) {
        String sql = "SELECT * FROM estatisticaIndividual WHERE idEstatisticaIndividual = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return extractEstatisticaIndividualFromResultSet(resultSet);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<EstatisticaIndividual> buscarTodos() {
        List<EstatisticaIndividual> estatisticas = new ArrayList<>();
        String sql = "SELECT * FROM estatisticaIndividual";
        try (Connection connection = gerenciadorConexao.obterConexao();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {
            while (resultSet.next()) {
                estatisticas.add(extractEstatisticaIndividualFromResultSet(resultSet));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return estatisticas;
    }

    @Override
    public void atualizar(EstatisticaIndividual estatisticaIndividual) {
        String sql = "UPDATE estatisticaIndividual SET idJogador = ?, golos = ?, assistencias = ?, jogos = ?, minutosJogados = ?, cartoesAmarelos = ?, cartoesVermelhos = ? " +
                "WHERE idEstatisticaIndividual = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, estatisticaIndividual.getIdJogador());
            statement.setInt(2, estatisticaIndividual.getGolos());
            statement.setInt(3, estatisticaIndividual.getAssistencias());
            statement.setInt(4, estatisticaIndividual.getJogos());
            statement.setInt(5, estatisticaIndividual.getMinutosJogados());
            statement.setInt(6, estatisticaIndividual.getCartoesAmarelos());
            statement.setInt(7, estatisticaIndividual.getCartoesVermelhos());
            statement.setInt(8, estatisticaIndividual.getIdEstatisticaIndividual());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void eliminar(int id) {
        String sql = "DELETE FROM estatisticaIndividual WHERE idEstatisticaIndividual = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private EstatisticaIndividual extractEstatisticaIndividualFromResultSet(ResultSet resultSet) throws SQLException {
        EstatisticaIndividual estatisticaIndividual = new EstatisticaIndividual();
        estatisticaIndividual.setIdEstatisticaIndividual(resultSet.getInt("idEstatisticaIndividual"));
        estatisticaIndividual.setIdJogador(resultSet.getInt("idJogador"));
        estatisticaIndividual.setGolos(resultSet.getInt("golos"));
        estatisticaIndividual.setAssistencias(resultSet.getInt("assistencias"));
        estatisticaIndividual.setJogos(resultSet.getInt("jogos"));
        estatisticaIndividual.setMinutosJogados(resultSet.getInt("minutosJogados"));
        estatisticaIndividual.setCartoesAmarelos(resultSet.getInt("cartoesAmarelos"));
        estatisticaIndividual.setCartoesVermelhos(resultSet.getInt("cartoesVermelhos"));
        return estatisticaIndividual;
    }
}
