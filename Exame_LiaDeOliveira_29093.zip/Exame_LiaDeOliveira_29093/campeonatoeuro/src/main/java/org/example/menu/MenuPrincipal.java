package org.example.menu;

import org.example.config.GerenciadorConexaoBD;
import org.example.gestao.*;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

public class MenuPrincipal {
    private final GerenciadorConexaoBD connectionManager;
    private final Scanner scanner;

    public MenuPrincipal() {
        this.connectionManager = new GerenciadorConexaoBD();
        this.scanner = new Scanner(System.in);
    }

    public void menu() {
        try {
            connectionManager.obterConexao();
            Connection connection = connectionManager.obterConexao();

            int opcao = 0;
            do {
                System.out.println("Menu Principal");
                System.out.println("1. Gestão de Países");
                System.out.println("2. Gestão de Cidades");
                System.out.println("3. Gestão de Estádios");
                System.out.println("4. Gestão de Fases");
                System.out.println("5. Gestão de Grupos");
                System.out.println("6. Gestão de Seleções");
                System.out.println("7. Gestão de Jogadores");
                System.out.println("8. Gestão de Jogos");
                System.out.println("9. Gestão de Golos");
                System.out.println("10. Gestão de Cartões");
                System.out.println("11. Gestão de Substituições");
                System.out.println("12. Gestão de Classificação Fase");
                System.out.println("13. Gestão de Classificação Grupo");
                System.out.println("14. Gestão de Estatística Individual");
                System.out.println("15. Gestão de Estatística Global");
                System.out.println("16. Gestão de Calendários");
                System.out.println("0. Para sair...");

                System.out.print("Escolha uma opção: ");

                // Verifica se há uma próxima linha disponível
                if (scanner.hasNextInt()) {
                    opcao = scanner.nextInt();
                    scanner.nextLine();  // Consume newline
                } else {
                    System.out.println("Opção inválida! Tente novamente.");
                    scanner.nextLine();  // Consume newline
                    continue;
                }

                switch (opcao) {
                    case 1 -> new GestaoPais().menu();
                    case 2 -> new GestaoCidade().menu();
                    case 3 -> new GestaoEstadio().menu();
                    case 4 -> new GestaoFase().menu();
                    case 5 -> new GestaoGrupo().menu();
                    case 6 -> new GestaoSelecao().menu();
                    case 7 -> new GestaoJogador().menu();
                    case 8 -> new GestaoJogo().menu();
                    case 9 -> new GestaoGolo().menu();
                    case 10 -> new GestaoCartao().menu();
                    case 11 -> new GestaoSubstituicao().menu();
                    case 12 -> new GestaoClassificacaoFase().menu();
                    case 13 -> new GestaoClassificacaoGrupo().menu();
                    case 14 -> new GestaoEstatisticaIndividual().menu();
                    case 15 -> new GestaoEstatisticaGlobal().menu();
                    case 16 -> new GestaoCalendario().menu();
                    case 0 -> System.out.println("Saindo...");
                    default -> System.out.println("Opção inválida! Tente novamente.");
                }
            } while (opcao != 0);

            connectionManager.fecharConexao();
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Erro ao conectar com o banco de dados.");
        }
    }


    public static void main(String[] args) {
        MenuPrincipal menuPrincipal = new MenuPrincipal();
        menuPrincipal.menu();
    }
}
