package org.example;

import org.example.config.GerenciadorConexaoBD;
import org.example.menu.MenuPrincipal;
import org.example.utils.InicializadorBaseDados;

public class Main {
    public static void main(String[] args) {
        InicializadorBaseDados();
        MenuPrincipal menuPrincipal = new MenuPrincipal();
        menuPrincipal.menu();
    }

    private static void InicializadorBaseDados() {
        GerenciadorConexaoBD connectionManagerDB = new GerenciadorConexaoBD();
        InicializadorBaseDados iniBD = new InicializadorBaseDados(connectionManagerDB);
        iniBD.initializeDatabase();
    }
}
