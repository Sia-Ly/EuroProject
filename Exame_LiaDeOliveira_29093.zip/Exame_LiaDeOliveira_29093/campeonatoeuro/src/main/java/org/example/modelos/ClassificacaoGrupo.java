package org.example.modelos;


public class ClassificacaoGrupo {
    private int idClassificacaoGrupo;
    private int idGrupo;
    private int idSelecao;
    private int pontos;
    private int jogos;
    private int vitorias;
    private int empates;
    private int derrotas;
    private int golosMarcados;
    private int golosSofridos;

    // Construtor vazio
    public ClassificacaoGrupo() {}

    // Construtor com parâmetros
    public ClassificacaoGrupo(int idClassificacaoGrupo, int idGrupo, int idSelecao, int pontos, int jogos, int vitorias, int empates, int derrotas, int golosMarcados, int golosSofridos) {
        this.idClassificacaoGrupo = idClassificacaoGrupo;
        this.idGrupo = idGrupo;
        this.idSelecao = idSelecao;
        this.pontos = pontos;
        this.jogos = jogos;
        this.vitorias = vitorias;
        this.empates = empates;
        this.derrotas = derrotas;
        this.golosMarcados = golosMarcados;
        this.golosSofridos = golosSofridos;
    }

    public int getIdClassificacaoGrupo() {
        return idClassificacaoGrupo;
    }

    public void setIdClassificacaoGrupo(int idClassificacaoGrupo) {
        this.idClassificacaoGrupo = idClassificacaoGrupo;
    }

    public int getIdGrupo() {
        return idGrupo;
    }

    public void setIdGrupo(int grupoId) {
        this.idGrupo = idGrupo;
    }

    public int getIdSelecao() {
        return idSelecao;
    }

    public void setIdSelecao(int idSelecao) {
        this.idSelecao = idSelecao;
    }

    public int getPontos() {
        return pontos;
    }

    public void setPontos(int pontos) {
        this.pontos = pontos;
    }

    public int getJogos() {
        return jogos;
    }

    public void setJogos(int jogos) {
        this.jogos = jogos;
    }

    public int getVitorias() {
        return vitorias;
    }

    public void setVitorias(int vitorias) {
        this.vitorias = vitorias;
    }

    public int getEmpates() {
        return empates;
    }

    public void setEmpates(int empates) {
        this.empates = empates;
    }

    public int getDerrotas() {
        return derrotas;
    }

    public void setDerrotas(int derrotas) {
        this.derrotas = derrotas;
    }

    public int getGolosMarcados() {
        return golosMarcados;
    }

    public void setGolosMarcados(int golosMarcados) {
        this.golosMarcados = golosMarcados;
    }

    public int getGolosSofridos() {
        return golosSofridos;
    }

    public void setGolosSofridos(int golosSofridos) {
        this.golosSofridos = golosSofridos;
    }

    @Override
    public String toString() {
        return "ClassificacaoGrupo{" +
                "idClassificacaoGrupo=" + idClassificacaoGrupo +
                ", IdGrupo=" + idGrupo +
                ", selecaoId=" + idSelecao +
                ", pontos=" + pontos +
                ", jogos=" + jogos +
                ", vitorias=" + vitorias +
                ", empates=" + empates +
                ", derrotas=" + derrotas +
                ", golosMarcados=" + golosMarcados +
                ", golosSofridos=" + golosSofridos +
                '}';
    }
}

