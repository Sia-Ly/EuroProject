package org.example.modelos;

import java.sql.Timestamp;

public class Calendario {
    private int idCalendario;
    private Timestamp data;
    private int idFase;
    private int idEstadio;


    public int getIdCalendario() {
        return idCalendario;
    }

    public void setIdCalendario(int idCalendario) {
        this.idCalendario = idCalendario;
    }

    public Timestamp getData() {
        return data;
    }

    public void setData(Timestamp data) {
        this.data = data;
    }

    public int getIdFase() {
        return idFase;
    }

    public void setIdFase(int idFase) {
        this.idFase = idFase;
    }

    public int getIdEstadio() {
        return idEstadio;
    }

    public void setIdEstadio(int idEstadio) {
        this.idEstadio = idEstadio;
    }

    @Override
    public String toString() {
        return "Calendario{" +
                "idCalendario=" + idCalendario +
                ", data=" + data +
                ", idFase=" + idFase +
                ", idEstadio=" + idEstadio +
                '}';
    }
}
