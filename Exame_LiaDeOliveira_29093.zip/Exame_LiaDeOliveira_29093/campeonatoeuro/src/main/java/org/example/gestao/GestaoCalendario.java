package org.example.gestao;

import org.example.dao.CalendarioDAO;
import org.example.dao.EstadioDAO;
import org.example.dao.FaseDAO;
import org.example.modelos.Calendario;
import org.example.modelos.Estadio;
import org.example.modelos.Fase;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;
import java.util.Scanner;

public class GestaoCalendario {
    private final CalendarioDAO calendarioDAO;
    private final FaseDAO faseDAO;
    private final EstadioDAO estadioDAO;
    private final Scanner scanner;

    public GestaoCalendario() {
        this.calendarioDAO = new CalendarioDAO();
        this.faseDAO = new FaseDAO();
        this.estadioDAO = new EstadioDAO();
        this.scanner = new Scanner(System.in);
    }

    public void menu() {
        int opcao;
        do {
            System.out.println("Gestão de Calendários");
            System.out.println("1. Adicionar Calendário");
            System.out.println("2. Listar Calendários");
            System.out.println("3. Atualizar Calendário");
            System.out.println("4. Remover Calendário");
            System.out.println("5. Voltar ao Menu Principal");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (opcao) {
                case 1 -> adicionarCalendario();
                case 2 -> listarCalendarios();
                case 3 -> atualizarCalendario();
                case 4 -> removerCalendario();
                case 5 -> System.out.println("Voltando ao Menu Principal...");
                default -> System.out.println("Opção inválida! Tente novamente.");
            }
        } while (opcao != 5);
    }

    private void adicionarCalendario() {
        List<Fase> fases = faseDAO.buscarTodos();
        if (fases.isEmpty()) {
            System.out.println("Nenhuma fase encontrada. Adicione fases primeiro.");
            return;
        }

        List<Estadio> estadios = estadioDAO.buscarTodos();
        if (estadios.isEmpty()) {
            System.out.println("Nenhum estádio encontrado. Adicione estádios primeiro.");
            return;
        }

        System.out.print("Digite a data e hora do calendário (formato: yyyy-MM-dd HH:mm:ss): ");
        String dataStr = scanner.nextLine();
        Timestamp data = Timestamp.valueOf(dataStr);

        System.out.println("Selecione a fase:");
        for (int i = 0; i < fases.size(); i++) {
            System.out.println((i + 1) + ". " + fases.get(i).getNome());
        }
        int faseIndex = scanner.nextInt() - 1;
        scanner.nextLine();  // Consume newline

        if (faseIndex < 0 || faseIndex >= fases.size()) {
            System.out.println("Fase inválida. Operação cancelada.");
            return;
        }

        System.out.println("Selecione o estádio:");
        for (int i = 0; i < estadios.size(); i++) {
            System.out.println((i + 1) + ". " + estadios.get(i).getNome());
        }
        int estadioIndex = scanner.nextInt() - 1;
        scanner.nextLine();  // Consume newline

        if (estadioIndex < 0 || estadioIndex >= estadios.size()) {
            System.out.println("Estádio inválido. Operação cancelada.");
            return;
        }

        Calendario calendario = new Calendario();
        calendario.setData(data);
        calendario.setIdFase(fases.get(faseIndex).getIdFase());
        calendario.setIdEstadio(estadios.get(estadioIndex).getIdEstadio());

        calendarioDAO.inserir(calendario);
        System.out.println("Calendário adicionado com sucesso!");
    }

    private void listarCalendarios() {
        List<Calendario> calendarios = calendarioDAO.buscarTodos();
        if (calendarios.isEmpty()) {
            System.out.println("Nenhum calendário encontrado.");
        } else {
            System.out.println("Lista de Calendários:");
            for (Calendario calendario : calendarios) {
                System.out.println("ID: " + calendario.getIdCalendario() + ", Data: " + calendario.getData() +
                        ", ID Fase: " + calendario.getIdFase() + ", ID Estadio: " + calendario.getIdEstadio());
            }
        }
    }

    private void atualizarCalendario() {
        System.out.print("Digite o ID do calendário que deseja atualizar: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        Calendario calendario = calendarioDAO.buscaPorId(id);
        if (calendario == null) {
            System.out.println("Calendário não encontrado.");
            return;
        }

        List<Fase> fases = faseDAO.buscarTodos();
        if (fases.isEmpty()) {
            System.out.println("Nenhuma fase encontrada. Adicione fases primeiro.");
            return;
        }

        List<Estadio> estadios = estadioDAO.buscarTodos();
        if (estadios.isEmpty()) {
            System.out.println("Nenhum estádio encontrado. Adicione estádios primeiro.");
            return;
        }

        System.out.print("Digite a nova data e hora do calendário (atual: " + calendario.getData() + ", formato: yyyy-MM-dd HH:mm:ss): ");
        String dataStr = scanner.nextLine();
        Timestamp data = Timestamp.valueOf(dataStr);

        System.out.println("Selecione a nova fase (atual: " + calendario.getIdFase() + "):");
        for (int i = 0; i < fases.size(); i++) {
            System.out.println((i + 1) + ". " + fases.get(i).getNome());
        }
        int faseIndex = scanner.nextInt() - 1;
        scanner.nextLine();  // Consume newline

        if (faseIndex < 0 || faseIndex >= fases.size()) {
            System.out.println("Fase inválida. Operação cancelada.");
            return;
        }

        System.out.println("Selecione o novo estádio (atual: " + calendario.getIdEstadio() + "):");
        for (int i = 0; i < estadios.size(); i++) {
            System.out.println((i + 1) + ". " + estadios.get(i).getNome());
        }
        int estadioIndex = scanner.nextInt() - 1;
        scanner.nextLine();  // Consume newline

        if (estadioIndex < 0 || estadioIndex >= estadios.size()) {
            System.out.println("Estádio inválido. Operação cancelada.");
            return;
        }

        calendario.setData(data);
        calendario.setIdFase(fases.get(faseIndex).getIdFase());
        calendario.setIdEstadio(estadios.get(estadioIndex).getIdEstadio());

        calendarioDAO.atualizar(calendario);
        System.out.println("Calendário atualizado com sucesso!");
    }

    private void removerCalendario() {
        List<Calendario> calendarios = calendarioDAO.buscarTodos();
        if (calendarios.isEmpty()) {
            System.out.println("Nenhum calendário encontrado.");
            return;
        }
        System.out.print("Digite o ID do calendário que deseja remover: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // Consume newline



        calendarioDAO.eliminar(id);
        System.out.println("Calendário removido com sucesso!");
    }
}
