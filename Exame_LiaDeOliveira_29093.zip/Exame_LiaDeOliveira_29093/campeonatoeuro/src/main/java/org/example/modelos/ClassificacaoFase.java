package org.example.modelos;

public class ClassificacaoFase {
    private int idClassificacaoFase;
    private int idFase;
    private int idSelecao;
    private int posicao;

    // Construtor vazio
    public ClassificacaoFase() {}

    // Construtor com parâmetros
    public ClassificacaoFase( int idFase, int idSelecao, int posicao) {
        this.idFase = idFase;
        this.idSelecao = idSelecao;
        this.posicao = posicao;
    }

    public int getIdClassificacaoFase() {
        return idClassificacaoFase;
    }

    public void setIdClassificacaoFase(int idClassificacaoFase) {
        this.idClassificacaoFase = idClassificacaoFase;
    }

    public int getIdFase() {
        return idFase;
    }

    public void setIdFase(int idFase) {
        this.idFase = idFase;
    }

    public int getIdSelecao() {
        return idSelecao;
    }

    public void setIdSelecao(int idSelecao) {
        this.idSelecao = idSelecao;
    }

    public int getPosicao() {
        return posicao;
    }

    public void setPosicao(int posicao) {
        this.posicao = posicao;
    }

    @Override
    public String toString() {
        return "ClassificacaoFase{" +
                "idClassificacaoFase=" + idClassificacaoFase +
                ", idFase=" + idFase +
                ", idSelecao=" + idSelecao +
                ", posicao=" + posicao +
                '}';
    }


}

