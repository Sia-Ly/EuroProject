package org.example.modelos;

public class Estadio {
    private int idEstadio;
    private String nome;
    private int capacidade;
    private int idCidade;

    // Construtor vazio
    public Estadio() {}

    // Construtor com parâmetros
    public Estadio(int idEstadio, String nome, int capacidade, int idCidade) {
        this.idEstadio = idEstadio;
        this.nome = nome;
        this.capacidade = capacidade;
        this.idCidade = idCidade;
    }

    public int getIdEstadio() {
        return idEstadio;
    }

    public void setIdEstadio(int idEstadio) {
        this.idEstadio = idEstadio;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCapacidade() {
        return capacidade;
    }

    public void setCapacidade(int capacidade) {
        this.capacidade = capacidade;
    }

    public int getIdCidade() {
        return idCidade;
    }

    public void setIdCidade(int idCidade) {
        this.idCidade = idCidade;
    }

    @Override
    public String toString() {
        return "Estadio{" +
                "idEstadio=" + idEstadio +
                ", nome='" + nome + '\'' +
                ", capacidade=" + capacidade +
                ", idCidade=" + idCidade +
                '}';
    }

}
