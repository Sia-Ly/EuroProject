package org.example.gestao;

import org.example.dao.CidadeDAO;
import org.example.dao.PaisDAO;
import org.example.modelos.Cidade;
import org.example.modelos.Pais;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class GestaoCidade {
    private final CidadeDAO cidadeDAO;
    private final PaisDAO paisDAO;
    private final Scanner scanner;

    public GestaoCidade() {
        this.cidadeDAO = new CidadeDAO();
        this.paisDAO = new PaisDAO();
        this.scanner = new Scanner(System.in);
    }

    public void menu() {
        int opcao;
        do {
            System.out.println("Gestão de Cidades");
            System.out.println("1. Adicionar Cidade");
            System.out.println("2. Listar Cidades");
            System.out.println("3. Atualizar Cidade");
            System.out.println("4. Remover Cidade");
            System.out.println("5. Voltar ao Menu Principal");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (opcao) {
                case 1 -> adicionarCidade();
                case 2 -> listarCidades();
                case 3 -> atualizarCidade();
                case 4 -> removerCidade();
                case 5 -> System.out.println("Voltando ao Menu Principal...");
                default -> System.out.println("Opção inválida! Tente novamente.");
            }
        } while (opcao != 5);
    }

    private void adicionarCidade() {
        List<Pais> paises = paisDAO.buscarTodos();
        if (paises.isEmpty()) {
            System.out.println("Nenhum país encontrado. Adicione países primeiro.");
            return;
        }

        System.out.print("Nome da cidade: ");
        String nome = scanner.nextLine();
        System.out.print("ID do país: ");
        int idPais = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        Cidade cidade = new Cidade(nome, idPais);
        cidadeDAO.inserir(cidade);
        System.out.println("Cidade adicionada com sucesso!");
    }

    private void listarCidades() {
        List<Cidade> cidades = cidadeDAO.buscarTodos();
        if (cidades.isEmpty()) {
            System.out.println("Nenhuma cidade encontrada.");
        } else {
            System.out.println("Cidades:");
            for (Cidade cidade : cidades) {
                System.out.println(cidade);
            }
        }
    }

    private void atualizarCidade() {
        List<Pais> paises = paisDAO.buscarTodos();
        if (paises.isEmpty()) {
            System.out.println("Nenhum país encontrado. Adicione países primeiro.");
            return;
        }

        System.out.print("ID da cidade: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        Cidade cidade = cidadeDAO.buscaPorId(id);
        if (cidade == null) {
            System.out.println("Cidade não encontrada.");
            return;
        }

        System.out.print("Nome da cidade: ");
        String nome = scanner.nextLine();
        System.out.print("ID do país: ");
        int idPais = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        cidade.setNome(nome);
        cidade.setIdPais(idPais);
        cidadeDAO.atualizar(cidade);
        System.out.println("Cidade atualizada com sucesso!");
    }

    private void removerCidade() {
        System.out.print("ID da cidade: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        Cidade cidade = cidadeDAO.buscaPorId(id);
        if (cidade == null) {
            System.out.println("Cidade não encontrada.");
            return;
        }

        cidadeDAO.eliminar(id);
        System.out.println("Cidade removida com sucesso!");
    }

}
