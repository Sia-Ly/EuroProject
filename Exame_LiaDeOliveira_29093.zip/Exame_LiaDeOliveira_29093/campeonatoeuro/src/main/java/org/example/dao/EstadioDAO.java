package org.example.dao;



import org.example.config.GerenciadorConexaoBD;
import org.example.modelos.Estadio;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EstadioDAO implements IDAO<Estadio>{

    private final GerenciadorConexaoBD gerenciadorConexao;

    public EstadioDAO() {
        this.gerenciadorConexao = new GerenciadorConexaoBD();
    }

    public void inserir(Estadio estadio) {
        String sql = "INSERT INTO estadio (idEstadio, nome, capacidade, idCidade) VALUES (?, ?, ?, ?)";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, estadio.getIdEstadio());
            statement.setString(2, estadio.getNome());
            statement.setInt(3, estadio.getCapacidade());
            statement.setInt(4, estadio.getIdCidade());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Estadio buscaPorId(int id) {
        String sql = "SELECT * FROM estadio WHERE idEstadio = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return extractEstadioFromResultSet(resultSet);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Estadio> buscarTodos() {
        List<Estadio> estadios = new ArrayList<>();
        String sql = "SELECT * FROM estadio";
        try (Connection connection = gerenciadorConexao.obterConexao();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {
            while (resultSet.next()) {
                estadios.add(extractEstadioFromResultSet(resultSet));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return estadios;
    }

    public void atualizar(Estadio estadio) {
        String sql = "UPDATE estadio SET nome = ?, capacidade = ?, idCidade = ? WHERE idEstadio = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, estadio.getNome());
            statement.setInt(2, estadio.getCapacidade());
            statement.setInt(3, estadio.getIdCidade());
            statement.setInt(4, estadio.getIdEstadio());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void eliminar(int id) {
        String sql = "DELETE FROM estadio WHERE idEstadio = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private Estadio extractEstadioFromResultSet(ResultSet resultSet) throws SQLException {
        Estadio estadio = new Estadio();
        estadio.setIdEstadio(resultSet.getInt("idEstadio"));
        estadio.setNome(resultSet.getString("nome"));
        estadio.setCapacidade(resultSet.getInt("capacidade"));
        estadio.setIdCidade(resultSet.getInt("idCidade"));
        return estadio;
    }
}

