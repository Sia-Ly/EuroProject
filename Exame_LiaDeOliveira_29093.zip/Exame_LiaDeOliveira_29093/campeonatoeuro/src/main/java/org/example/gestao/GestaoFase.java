package org.example.gestao;

import org.example.dao.FaseDAO;
import org.example.modelos.Fase;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class GestaoFase {
    private final FaseDAO faseDAO;
    private final Scanner scanner;

    public GestaoFase() {
        this.faseDAO = new FaseDAO();
        this.scanner = new Scanner(System.in);
    }

    public void menu() {
        int opcao;
        do {
            System.out.println("Gestão de Fases");
            System.out.println("1. Adicionar Fase");
            System.out.println("2. Listar Fases");
            System.out.println("3. Atualizar Fase");
            System.out.println("4. Remover Fase");
            System.out.println("5. Voltar ao Menu Principal");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (opcao) {
                case 1 -> adicionarFase();
                case 2 -> listarFases();
                case 3 -> atualizarFase();
                case 4 -> removerFase();
                case 5 -> System.out.println("Voltando ao Menu Principal...");
                default -> System.out.println("Opção inválida! Tente novamente.");
            }
        } while (opcao != 5);
    }

    private void adicionarFase() {
        System.out.print("Digite o nome da fase: ");
        String nome = scanner.nextLine();

        Fase fase = new Fase();
        fase.setNome(nome);

        faseDAO.inserir(fase);
        System.out.println("Fase adicionada com sucesso!");
    }

    private void listarFases() {
        List<Fase> fases = faseDAO.buscarTodos();
        if (fases.isEmpty()) {
            System.out.println("Nenhuma fase encontrada.");
        } else {
            System.out.println("Lista de Fases:");
            for (Fase fase : fases) {
                System.out.println(fase);
            }
        }
    }

    private void atualizarFase() {
        System.out.print("Digite o ID da fase que deseja atualizar: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        Fase fase = faseDAO.buscaPorId(id);
        if (fase == null) {
            System.out.println("Fase não encontrada.");
            return;
        }

        System.out.print("Digite o novo nome da fase: ");
        String nome = scanner.nextLine();

        fase.setNome(nome);

        faseDAO.atualizar(fase);
        System.out.println("Fase atualizada com sucesso!");
    }

    private void removerFase() {

        System.out.print("Digite o ID da fase que deseja remover: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        faseDAO.eliminar(id);
        System.out.println("Fase removida com sucesso!");
    }
}
