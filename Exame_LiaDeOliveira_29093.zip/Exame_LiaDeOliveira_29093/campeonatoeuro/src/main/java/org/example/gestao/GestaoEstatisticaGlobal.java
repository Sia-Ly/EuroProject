package org.example.gestao;

import org.example.dao.EstatisticaGlobalDAO;
import org.example.dao.SelecaoDAO;
import org.example.dao.JogoDAO;
import org.example.modelos.EstatisticaGlobal;
import org.example.modelos.Selecao;
import org.example.modelos.Jogo;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class GestaoEstatisticaGlobal {
    private final EstatisticaGlobalDAO estatisticaGlobalDAO;
    private final SelecaoDAO selecaoDAO;
    private final JogoDAO jogoDAO;
    private final Scanner scanner;

    public GestaoEstatisticaGlobal() {
        this.estatisticaGlobalDAO = new EstatisticaGlobalDAO();
        this.selecaoDAO = new SelecaoDAO();
        this.jogoDAO = new JogoDAO();
        this.scanner = new Scanner(System.in);
    }

    public void menu() {
        int opcao;
        do {
            System.out.println("Gestão de Estatísticas Globais");
            System.out.println("1. Adicionar Estatística Global");
            System.out.println("2. Listar Estatísticas Globais");
            System.out.println("3. Atualizar Estatística Global");
            System.out.println("4. Remover Estatística Global");
            System.out.println("5. Voltar ao Menu Principal");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (opcao) {
                case 1 -> adicionarEstatisticaGlobal();
                case 2 -> listarEstatisticasGlobais();
                case 3 -> atualizarEstatisticaGlobal();
                case 4 -> removerEstatisticaGlobal();
                case 5 -> System.out.println("Voltando ao Menu Principal...");
                default -> System.out.println("Opção inválida! Tente novamente.");
            }
        } while (opcao != 5);
    }

    private void adicionarEstatisticaGlobal() {
        System.out.print("Digite o ID do Jogo: ");
        int idJogo = scanner.nextInt();
        System.out.print("Digite o ID da Seleção: ");
        int idSelecao = scanner.nextInt();
        System.out.print("Digite o número de remates: ");
        int remates = scanner.nextInt();
        System.out.print("Digite o número de livres: ");
        int livres = scanner.nextInt();
        System.out.print("Digite o número de foras de jogo: ");
        int forasJogo = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        EstatisticaGlobal estatistica = new EstatisticaGlobal(idJogo, idSelecao, remates, livres, forasJogo);
        estatisticaGlobalDAO.inserir(estatistica);
        System.out.println("Estatística Global adicionada com sucesso!");
    }

    private void listarEstatisticasGlobais() {
        List<EstatisticaGlobal> estatisticas = estatisticaGlobalDAO.buscarTodos();
        if (estatisticas.isEmpty()) {
            System.out.println("Não há estatísticas globais cadastradas.");
        } else {
            estatisticas.forEach(System.out::println);
        }
    }

    private void atualizarEstatisticaGlobal() {
        List<EstatisticaGlobal> estatisticaGlobais = estatisticaGlobalDAO.buscarTodos();

        if (estatisticaGlobais.isEmpty()){
            System.out.println("Nenhuma estatistica global");
            return;
        }

        for(int i = 0; i < estatisticaGlobais.size(); i++){
            System.out.println((i+1) + estatisticaGlobais.get(i).toString());
        }
        System.out.println("Escolha a Estatistica Global");
        int id = scanner.nextInt();

        EstatisticaGlobal estatisticaGlobal = estatisticaGlobais.get(id);
        if (estatisticaGlobal == null){
            System.out.println("Estatistica Global não encontrada");
            return;
        }
        System.out.print("Digite o ID do Jogo: ");
        int idJogo = scanner.nextInt();
        System.out.print("Digite o ID da Seleção: ");
        int idSelecao = scanner.nextInt();
        System.out.print("Digite o número de remates: ");
        int remates = scanner.nextInt();
        System.out.print("Digite o número de livres: ");
        int livres = scanner.nextInt();
        System.out.print("Digite o número de foras de jogo: ");
        int forasJogo = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        
        estatisticaGlobal.setIdJogo(idJogo);
        estatisticaGlobal.setIdSelecao(idSelecao);
        estatisticaGlobal.setRemates(remates);
        estatisticaGlobal.setLivres(livres);
        estatisticaGlobal.setForasJogo(forasJogo);
        estatisticaGlobalDAO.atualizar(estatisticaGlobal);
        System.out.println("Estatistica Global atualizada com sucesso!");
    }

    private EstatisticaGlobal removerEstatisticaGlobal(){
        List<EstatisticaGlobal> estatisticaGlobais = estatisticaGlobalDAO.buscarTodos();

        if (estatisticaGlobais.isEmpty()){
            System.out.println("Nenhuma estatistica");
            return null;
        }

        for(int i = 0; i < estatisticaGlobais.size(); i++){
            System.out.println((i+1) + estatisticaGlobais.get(i).toString());
        }
        System.out.println("Escolha a id da estatistica que pretende eliminar");
        int id = scanner.nextInt();

        EstatisticaGlobal esta = estatisticaGlobalDAO.buscaPorId(id);
        if (esta == null){
            System.out.println("Estatistica não encontrada");
            return null;
        }
        return estatisticaGlobais.remove(id);
    }



}
