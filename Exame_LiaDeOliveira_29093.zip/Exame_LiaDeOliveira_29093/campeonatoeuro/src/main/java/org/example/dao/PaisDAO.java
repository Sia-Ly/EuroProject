package org.example.dao;

import org.example.config.GerenciadorConexaoBD;
import org.example.modelos.Pais;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PaisDAO implements IDAO<Pais>{

    private final GerenciadorConexaoBD gerenciadorConexao;

    public PaisDAO() {
        this.gerenciadorConexao = new GerenciadorConexaoBD();
    }


    public void inserir(Pais pais) {
        String sql = "INSERT INTO pais (idPais, nome, codigoIso) VALUES (?, ?, ?)";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, pais.getIdPais());
            statement.setString(2, pais.getNome());
            statement.setString(3, pais.getCodigoIso());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public Pais buscaPorId(int id) {
        String sql = "SELECT * FROM pais WHERE idPais = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return extractPaisFromResultSet(resultSet);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }


    public List<Pais> buscarTodos() {
        List<Pais> paises = new ArrayList<>();
        String sql = "SELECT * FROM pais";
        try (Connection connection = gerenciadorConexao.obterConexao();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {
            while (resultSet.next()) {
                paises.add(extractPaisFromResultSet(resultSet));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return paises;
    }


    public void atualizar(Pais pais) {
        String sql = "UPDATE pais SET nome = ?, codigoIso = ? WHERE idPais = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, pais.getNome());
            statement.setString(2, pais.getCodigoIso());
            statement.setInt(3, pais.getIdPais());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public void eliminar(int id) {
        String sql = "DELETE FROM pais WHERE idPais = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    private Pais extractPaisFromResultSet(ResultSet resultSet) throws SQLException {
        Pais pais = new Pais();
        pais.setIdPais(resultSet.getInt("idPais"));
        pais.setNome(resultSet.getString("nome"));
        pais.setCodigoIso(resultSet.getString("codigoIso"));
        return pais;
    }
}
