package org.example.dao;

import org.example.config.GerenciadorConexaoBD;
import org.example.modelos.Jogador;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class JogadorDAO implements IDAO<Jogador>{

    private final GerenciadorConexaoBD gerenciadorConexao;

    public JogadorDAO() {
        this.gerenciadorConexao = new GerenciadorConexaoBD();
    }

    public void inserir(Jogador jogador) {
        String sql = "INSERT INTO jogador (idJogador, nome, dataNascimento, posicao, idSelecao) VALUES (?, ?, ?, ?, ?)";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, jogador.getIdJogador());
            statement.setString(2, jogador.getNome());
            statement.setDate(3, new java.sql.Date(jogador.getDataNascimento().getTime()));
            statement.setString(4, jogador.getPosicao());
            statement.setInt(5, jogador.getIdSelecao());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Jogador buscaPorId(int id) {
        String sql = "SELECT * FROM jogador WHERE idJogador = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return extractJogadorFromResultSet(resultSet);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Jogador> buscarTodos() {
        List<Jogador> jogadores = new ArrayList<>();
        String sql = "SELECT * FROM jogador";
        try (Connection connection = gerenciadorConexao.obterConexao();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {
            while (resultSet.next()) {
                jogadores.add(extractJogadorFromResultSet(resultSet));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return jogadores;
    }

    public void atualizar(Jogador jogador) {
        String sql = "UPDATE jogador SET nome = ?, dataNascimento = ?, posicao = ?, idSelecao = ? WHERE idJogador = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, jogador.getNome());
            statement.setDate(2, new java.sql.Date(jogador.getDataNascimento().getTime()));
            statement.setString(3, jogador.getPosicao());
            statement.setInt(4, jogador.getIdSelecao());
            statement.setInt(5, jogador.getIdJogador());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void eliminar(int id) {
        String sql = "DELETE FROM jogador WHERE idJogador = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private Jogador extractJogadorFromResultSet(ResultSet resultSet) throws SQLException {
        Jogador jogador = new Jogador();
        jogador.setIdJogador(resultSet.getInt("idJogador"));
        jogador.setNome(resultSet.getString("nome"));
        jogador.setDataNascimento(resultSet.getTimestamp("dataNascimento"));
        jogador.setPosicao(resultSet.getString("posicao"));
        jogador.setIdSelecao(resultSet.getInt("idSelecao"));
        return jogador;
    }
}

