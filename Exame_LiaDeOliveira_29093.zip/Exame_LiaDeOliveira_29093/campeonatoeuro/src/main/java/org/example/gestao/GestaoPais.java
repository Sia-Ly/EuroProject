package org.example.gestao;

import org.example.dao.PaisDAO;
import org.example.modelos.Pais;


import java.util.List;
import java.util.Scanner;

public class GestaoPais {
    private final PaisDAO paisDAO;
    private final Scanner scanner;

    public GestaoPais() {
        this.paisDAO = new PaisDAO();
        this.scanner = new Scanner(System.in);
    }

    public void menu() {
        int opcao;
        do {
            System.out.println("Gestão de Países");
            System.out.println("1. Adicionar País");
            System.out.println("2. Listar Países");
            System.out.println("3. Atualizar País");
            System.out.println("4. Remover País");
            System.out.println("5. Voltar ao Menu Principal");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (opcao) {
                case 1 -> adicionarPais();
                case 2 -> listarPaises();
                case 3 -> atualizarPais();
                case 4 -> removerPais();
                case 5 -> System.out.println("Voltando ao Menu Principal...");
                default -> System.out.println("Opção inválida! Tente novamente.");
            }
        } while (opcao != 5);
        scanner.close();
    }

    private void adicionarPais() {
        System.out.print("Digite o nome do país: ");
        String nome = scanner.nextLine();
        System.out.print("Digite o código ISO do país: ");
        String codigoIso = scanner.nextLine();

        Pais pais = new Pais();
        pais.setNome(nome);
        pais.setCodigoIso(codigoIso);

        paisDAO.inserir(pais);
        System.out.println("País adicionado com sucesso!");
    }

    private void listarPaises() {
        List<Pais> paises = paisDAO.buscarTodos();
        if (paises.isEmpty()) {
            System.out.println("Nenhum país encontrado.");
        } else {
            System.out.println("Lista de Países:");
            for (Pais pais : paises) {
                System.out.println("ID: " + pais.getIdPais() + ", Nome: " + pais.getNome() + ", Código ISO: " + pais.getCodigoIso());
            }
        }
    }

    private void atualizarPais() {
        System.out.print("Digite o ID do país que deseja atualizar: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        Pais pais = paisDAO.buscaPorId(id);
        if (pais == null) {
            System.out.println("País não encontrado.");
            return;
        }

        System.out.print("Digite o novo nome do país (atual: " + pais.getNome() + "): ");
        String nome = scanner.nextLine();
        System.out.print("Digite o novo código ISO do país (atual: " + pais.getCodigoIso() + "): ");
        String codigoIso = scanner.nextLine();

        pais.setNome(nome);
        pais.setCodigoIso(codigoIso);

        paisDAO.atualizar(pais);
        System.out.println("País atualizado com sucesso!");
    }

    private void removerPais() {
        System.out.print("Digite o ID do país que deseja remover: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        paisDAO.eliminar(id);
        System.out.println("País removido com sucesso!");
    }
}
