package org.example.dao;

import org.example.config.GerenciadorConexaoBD;
import org.example.modelos.Cidade;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CidadeDAO implements IDAO<Cidade>{

    private final GerenciadorConexaoBD gerenciadorConexao;

    public CidadeDAO() {
        this.gerenciadorConexao = new GerenciadorConexaoBD();
    }

    @Override
    public void inserir(Cidade cidade) {
        String sql = "INSERT INTO cidade (idCidade, nome, idPais) VALUES (?, ?, ?)";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, cidade.getIdCidade());
            statement.setString(2, cidade.getNome());
            statement.setInt(3, cidade.getIdPais());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Cidade buscaPorId(int id) {
        String sql = "SELECT * FROM cidade WHERE idCidade = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return extractCidadeFromResultSet(resultSet);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Cidade> buscarTodos() {
        List<Cidade> cidades = new ArrayList<>();
        String sql = "SELECT * FROM cidade";
        try (Connection connection = gerenciadorConexao.obterConexao();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {
            while (resultSet.next()) {
                cidades.add(extractCidadeFromResultSet(resultSet));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return cidades;
    }

    @Override
    public void atualizar(Cidade cidade) {
        String sql = "UPDATE cidade SET nome = ?, idPais = ? WHERE idCidade = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, cidade.getNome());
            statement.setInt(2, cidade.getIdPais());
            statement.setInt(3, cidade.getIdCidade());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void eliminar(int id) {
        String sql = "DELETE FROM cidade WHERE idCidade = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private Cidade extractCidadeFromResultSet(ResultSet resultSet) throws SQLException {
        Cidade cidade = new Cidade();
        cidade.setIdCidade(resultSet.getInt("idCidade"));
        cidade.setNome(resultSet.getString("nome"));
        cidade.setIdPais(resultSet.getInt("idPais"));
        return cidade;
    }
}
