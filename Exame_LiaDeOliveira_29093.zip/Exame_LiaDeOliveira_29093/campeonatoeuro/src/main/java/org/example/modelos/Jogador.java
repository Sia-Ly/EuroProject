package org.example.modelos;

import java.sql.Timestamp;

public class Jogador {
    private int idJogador;
    private String nome;
    private Timestamp dataNascimento;
    private String posicao;
    private int idSelecao;

    // Construtor vazio
    public Jogador() {}

    // Construtor com parâmetros
    public Jogador(int idJogador, String nome, Timestamp dataNascimento, String posicao, int idSelecao) {
        this.idJogador = idJogador;
        this.nome = nome;
        this.dataNascimento = dataNascimento;
        this.posicao = posicao;
        this.idSelecao = idSelecao;
    }

    public int getIdJogador() {
        return idJogador;
    }

    public void setIdJogador(int idJogador) {
        this.idJogador = idJogador;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Timestamp getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(Timestamp dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public String getPosicao() {
        return posicao;
    }

    public void setPosicao(String posicao) {
        this.posicao = posicao;
    }

    public int getIdSelecao() {
        return idSelecao;
    }

    public void setIdSelecao(int idSelecao) {
        this.idSelecao = idSelecao;
    }

    @Override
    public String toString() {
        return "Jogador{" +
                "idJogador=" + idJogador +
                ", nome='" + nome + '\'' +
                ", dataNascimento=" + dataNascimento +
                ", posicao='" + posicao + '\'' +
                ", selecaoId=" + idSelecao +
                '}';
    }
}

