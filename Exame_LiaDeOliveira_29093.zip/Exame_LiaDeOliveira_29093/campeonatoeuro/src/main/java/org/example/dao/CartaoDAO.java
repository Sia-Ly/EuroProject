package org.example.dao;

import  org.example.modelos.Cartao;

import java.util.List;

public class CartaoDAO implements IDAO<Cartao>{

    @Override
    public void inserir(Cartao cartao) {

    }

    @Override
    public void atualizar(Cartao cartao) {

    }

    @Override
    public void eliminar(int id) {

    }

    @Override
    public Cartao buscaPorId(int id) {
        return null;
    }

    @Override
    public List<Cartao> buscarTodos() {
        return List.of();
    }
}
