package org.example.gestao;

import org.example.dao.EstatisticaIndividualDAO;
import org.example.modelos.EstatisticaIndividual;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class GestaoEstatisticaIndividual {
    private final EstatisticaIndividualDAO estatisticaIndividualDao;
    private final Scanner scanner;

    public GestaoEstatisticaIndividual() {
        this.estatisticaIndividualDao = new EstatisticaIndividualDAO();
        this.scanner = new Scanner(System.in);
    }

    public void menu() {
        int opcao;
        do {
            System.out.println("Menu de Gestão de Estatísticas Individuais");
            System.out.println("1. Criar Estatística Individual");
            System.out.println("2. Atualizar Estatística Individual");
            System.out.println("3. Deletar Estatística Individual");
            System.out.println("4. Listar Estatísticas Individuais");
            System.out.println("0. Voltar ao Menu Principal");

            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (opcao) {
                case 1 -> criarEstatisticaIndividual();
                case 2 -> atualizarEstatisticaIndividual();
                case 3 -> deletarEstatisticaIndividual();
                case 4 -> listarEstatisticasIndividuais();
                case 0 -> System.out.println("Voltando ao Menu Principal...");
                default -> System.out.println("Opção inválida! Tente novamente.");
            }
        } while (opcao != 0);
    }

    private void criarEstatisticaIndividual() {
        System.out.print("ID do Jogador: ");
        int idJogador = scanner.nextInt();
        System.out.print("Golos: ");
        int golos = scanner.nextInt();
        System.out.print("Assistências: ");
        int assistencias = scanner.nextInt();
        System.out.print("Jogos: ");
        int jogos = scanner.nextInt();
        System.out.print("Minutos Jogados: ");
        int minutosJogados = scanner.nextInt();
        System.out.print("Cartões Amarelos: ");
        int cartoesAmarelos = scanner.nextInt();
        System.out.print("Cartões Vermelhos: ");
        int cartoesVermelhos = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        EstatisticaIndividual estatistica = new EstatisticaIndividual(0, idJogador, golos, assistencias, jogos, minutosJogados, cartoesAmarelos, cartoesVermelhos);

        estatisticaIndividualDao.inserir(estatistica);
        System.out.println("Estatística Individual criada com sucesso!");
    }

    private void atualizarEstatisticaIndividual() {
        System.out.print("ID da Estatística Individual a ser atualizada: ");
        int idEstatisticaIndividual = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        EstatisticaIndividual estatistica = estatisticaIndividualDao.buscaPorId(idEstatisticaIndividual);
        if (estatistica == null) {
            System.out.println("Estatística Individual não encontrada!");
            return;
        }

        System.out.print("ID do Jogador (" + estatistica.getIdJogador() + "): ");
        String idJogadorStr = scanner.nextLine();
        if (!idJogadorStr.isEmpty()) estatistica.setIdJogador(Integer.parseInt(idJogadorStr));

        System.out.print("Golos (" + estatistica.getGolos() + "): ");
        String golosStr = scanner.nextLine();
        if (!golosStr.isEmpty()) estatistica.setGolos(Integer.parseInt(golosStr));

        System.out.print("Assistências (" + estatistica.getAssistencias() + "): ");
        String assistenciasStr = scanner.nextLine();
        if (!assistenciasStr.isEmpty()) estatistica.setAssistencias(Integer.parseInt(assistenciasStr));

        System.out.print("Jogos (" + estatistica.getJogos() + "): ");
        String jogosStr = scanner.nextLine();
        if (!jogosStr.isEmpty()) estatistica.setJogos(Integer.parseInt(jogosStr));

        System.out.print("Minutos Jogados (" + estatistica.getMinutosJogados() + "): ");
        String minutosJogadosStr = scanner.nextLine();
        if (!minutosJogadosStr.isEmpty()) estatistica.setMinutosJogados(Integer.parseInt(minutosJogadosStr));

        System.out.print("Cartões Amarelos (" + estatistica.getCartoesAmarelos() + "): ");
        String cartoesAmarelosStr = scanner.nextLine();
        if (!cartoesAmarelosStr.isEmpty()) estatistica.setCartoesAmarelos(Integer.parseInt(cartoesAmarelosStr));

        System.out.print("Cartões Vermelhos (" + estatistica.getCartoesVermelhos() + "): ");
        String cartoesVermelhosStr = scanner.nextLine();
        if (!cartoesVermelhosStr.isEmpty()) estatistica.setCartoesVermelhos(Integer.parseInt(cartoesVermelhosStr));

        estatisticaIndividualDao.atualizar(estatistica);
        System.out.println("Estatística Individual atualizada com sucesso!");

    }

    private void deletarEstatisticaIndividual() {
        System.out.print("ID da Estatística Individual a ser deletada: ");
        int idEstatisticaIndividual = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        estatisticaIndividualDao.eliminar(idEstatisticaIndividual);
        System.out.println("Estatística Individual deletada com sucesso!");
    }

    private void listarEstatisticasIndividuais() {
        List<EstatisticaIndividual> estatisticas = estatisticaIndividualDao.buscarTodos();
        if (estatisticas.isEmpty()) {
            System.out.println("Nenhuma estatística individual encontrada.");
        } else {
            estatisticas.forEach(estatistica -> System.out.println(estatistica.toString()));
        }
    }
}
