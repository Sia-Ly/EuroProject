package org.example.modelos;

public class Grupo {
    private int idGrupo;
    private String nome;
    private int idFase;

    // Construtor vazio
    public Grupo() {}

    // Construtor com parâmetros
    public Grupo(int idGrupo, String nome, int idFase) {
        this.idGrupo = idGrupo;
        this.nome = nome;
        this.idFase = idFase;
    }


    public int getIdGrupo() {
        return idGrupo;
    }

    public void setIdGrupo(int idGrupo) {
        this.idGrupo = idGrupo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdFase() {
        return idFase;
    }

    public void setIdFase(int idFase) {
        this.idFase = idFase;
    }
}

