package org.example.dao;

import org.example.config.GerenciadorConexaoBD;
import org.example.modelos.EstatisticaGlobal;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EstatisticaGlobalDAO implements IDAO<EstatisticaGlobal> {

    private final GerenciadorConexaoBD gerenciadorConexao;

    public EstatisticaGlobalDAO() {
        this.gerenciadorConexao = new GerenciadorConexaoBD();
    }

    @Override
    public void inserir(EstatisticaGlobal estatisticaGlobal) {
        String sql = "INSERT INTO estatisticaGlobal (idEstatisticaGlobal, idSelecao, remates, livres, idJogo, forasJogo) " +
                "VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, estatisticaGlobal.getIdEstatisticaGlobal());
            statement.setInt(2, estatisticaGlobal.getIdSelecao());
            statement.setInt(3, estatisticaGlobal.getRemates());
            statement.setInt(4, estatisticaGlobal.getLivres());
            statement.setInt(5, estatisticaGlobal.getIdJogo());
            statement.setInt(6, estatisticaGlobal.getForasJogo());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public EstatisticaGlobal buscaPorId(int id) {
        String sql = "SELECT * FROM estatisticaGlobal WHERE idEstatisticaGlobal = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return extractEstatisticaGlobalFromResultSet(resultSet);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<EstatisticaGlobal> buscarTodos() {
        List<EstatisticaGlobal> estatisticas = new ArrayList<>();
        String sql = "SELECT * FROM estatisticaGlobal";
        try (Connection connection = gerenciadorConexao.obterConexao();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {
            while (resultSet.next()) {
                estatisticas.add(extractEstatisticaGlobalFromResultSet(resultSet));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return estatisticas;
    }

    @Override
    public void atualizar(EstatisticaGlobal estatisticaGlobal) {
        String sql = "UPDATE estatisticaGlobal SET idSelecao = ?, remates = ?, livres = ?, forasJogo = ?, idJogo = ?" +
                "WHERE idEstatisticaGlobal = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, estatisticaGlobal.getIdSelecao());
            statement.setInt(2, estatisticaGlobal.getRemates());
            statement.setInt(3, estatisticaGlobal.getLivres());
            statement.setInt(4, estatisticaGlobal.getForasJogo());
            statement.setInt(5, estatisticaGlobal.getIdJogo());
            statement.setInt(6, estatisticaGlobal.getIdEstatisticaGlobal());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void eliminar(int id) {
        String sql = "DELETE FROM estatisticaGlobal WHERE idEstatisticaGlobal = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private EstatisticaGlobal extractEstatisticaGlobalFromResultSet(ResultSet resultSet) throws SQLException {
        EstatisticaGlobal estatisticaGlobal = new EstatisticaGlobal();
        estatisticaGlobal.setIdEstatisticaGlobal(resultSet.getInt("idEstatisticaGlobal"));
        estatisticaGlobal.setIdSelecao(resultSet.getInt("idSelecao"));
        estatisticaGlobal.setIdJogo(resultSet.getInt("idJogo"));
        estatisticaGlobal.setRemates(resultSet.getInt("remates"));
        estatisticaGlobal.setLivres(resultSet.getInt("livres"));
        estatisticaGlobal.setForasJogo(resultSet.getInt("forasJogo"));
        return estatisticaGlobal;
    }
}
