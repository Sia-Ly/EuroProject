package org.example.dao;

import org.example.config.GerenciadorConexaoBD;
import org.example.modelos.Jogo;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class JogoDAO implements IDAO<Jogo> {

    private final GerenciadorConexaoBD gerenciadorConexao;

    public JogoDAO() {
        this.gerenciadorConexao = new GerenciadorConexaoBD();
    }

    @Override
    public void inserir(Jogo jogo) {
        String sql = "INSERT INTO jogo (idEstadio, dataHora, idFase, idGrupo, idSelecaoLocal, idSelecaoVisitante, golsLocal, golsVisitante) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            statement.setInt(1, jogo.getIdEstadio());
            statement.setTimestamp(2, jogo.getDataHora());
            statement.setInt(3, jogo.getIdFase());
            statement.setInt(4, jogo.getIdGrupo());
            statement.setInt(5, jogo.getIdSelecaoLocal());
            statement.setInt(6, jogo.getIdSelecaoVisitante());
            statement.setInt(7, jogo.getGolsLocal());
            statement.setInt(8, jogo.getGolsVisitante());
            statement.executeUpdate();

            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    jogo.setIdJogo(generatedKeys.getInt(1));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Jogo buscaPorId(int id) {
        String sql = "SELECT * FROM jogo WHERE idJogo = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return extractJogoFromResultSet(resultSet);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Jogo> buscarTodos() {
        List<Jogo> jogos = new ArrayList<>();
        String sql = "SELECT * FROM jogo";
        try (Connection connection = gerenciadorConexao.obterConexao();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {
            while (resultSet.next()) {
                jogos.add(extractJogoFromResultSet(resultSet));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return jogos;
    }

    @Override
    public void atualizar(Jogo jogo) {
        String sql = "UPDATE jogo SET idEstadio = ?, dataHora = ?, idFase = ?, idGrupo = ?, idSelecaoLocal = ?, idSelecaoVisitante = ?, golsLocal = ?, golsVisitante = ? WHERE idJogo = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, jogo.getIdEstadio());
            statement.setTimestamp(2, jogo.getDataHora());
            statement.setInt(3, jogo.getIdFase());
            statement.setInt(4, jogo.getIdGrupo());
            statement.setInt(5, jogo.getIdSelecaoLocal());
            statement.setInt(6, jogo.getIdSelecaoVisitante());
            statement.setInt(7, jogo.getGolsLocal());
            statement.setInt(8, jogo.getGolsVisitante());
            statement.setInt(9, jogo.getIdJogo());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void eliminar(int id) {
        String sql = "DELETE FROM jogo WHERE idJogo = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private Jogo extractJogoFromResultSet(ResultSet resultSet) throws SQLException {
        Jogo jogo = new Jogo();
        jogo.setIdJogo(resultSet.getInt("idJogo"));
        jogo.setIdEstadio(resultSet.getInt("idEstadio"));
        jogo.setDataHora(resultSet.getTimestamp("dataHora"));
        jogo.setIdFase(resultSet.getInt("idFase"));
        jogo.setIdGrupo(resultSet.getInt("idGrupo"));
        jogo.setIdSelecaoLocal(resultSet.getInt("idSelecaoLocal"));
        jogo.setIdSelecaoVisitante(resultSet.getInt("idSelecaoVisitante"));
        jogo.setGolsLocal(resultSet.getInt("golsLocal"));
        jogo.setGolsVisitante(resultSet.getInt("golsVisitante"));
        return jogo;
    }
}
