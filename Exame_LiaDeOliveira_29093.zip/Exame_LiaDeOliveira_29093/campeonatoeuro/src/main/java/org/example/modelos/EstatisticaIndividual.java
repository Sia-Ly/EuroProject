package org.example.modelos;


public class EstatisticaIndividual {
    private int idEstatisticaIndividual;
    private int idJogador;
    private int golos;
    private int assistencias;
    private int jogos;
    private int minutosJogados;
    private int cartoesAmarelos;
    private int cartoesVermelhos;

    // Construtor vazio
    public EstatisticaIndividual() {}

    // Construtor com parâmetros
    public EstatisticaIndividual(int idEstatisticaIndividual, int idJogador, int golos, int assistencias, int jogos, int minutosJogados, int cartoesAmarelos, int cartoesVermelhos) {
        this.idEstatisticaIndividual = idEstatisticaIndividual;
        this.idJogador = idJogador;
        this.golos = golos;
        this.assistencias = assistencias;
        this.jogos = jogos;
        this.minutosJogados = minutosJogados;
        this.cartoesAmarelos = cartoesAmarelos;
        this.cartoesVermelhos = cartoesVermelhos;
    }


    public int getIdEstatisticaIndividual() {
        return idEstatisticaIndividual;
    }

    public void setIdEstatisticaIndividual(int idEstatisticaIndividual) {
        this.idEstatisticaIndividual = idEstatisticaIndividual;
    }

    public int getIdJogador() {
        return idJogador;
    }

    public void setIdJogador(int idJogador) {
        this.idJogador = idJogador;
    }

    public int getGolos() {
        return golos;
    }

    public void setGolos(int golos) {
        this.golos = golos;
    }

    public int getAssistencias() {
        return assistencias;
    }

    public void setAssistencias(int assistencias) {
        this.assistencias = assistencias;
    }

    public int getJogos() {
        return jogos;
    }

    public void setJogos(int jogos) {
        this.jogos = jogos;
    }

    public int getMinutosJogados() {
        return minutosJogados;
    }

    public void setMinutosJogados(int minutosJogados) {
        this.minutosJogados = minutosJogados;
    }

    public int getCartoesAmarelos() {
        return cartoesAmarelos;
    }

    public void setCartoesAmarelos(int cartoesAmarelos) {
        this.cartoesAmarelos = cartoesAmarelos;
    }

    public int getCartoesVermelhos() {
        return cartoesVermelhos;
    }

    public void setCartoesVermelhos(int cartoesVermelhos) {
        this.cartoesVermelhos = cartoesVermelhos;
    }
    
    @Override
    public String toString() {
        return "EstatisticaIndividual{" +
                "idEstatisticaIndividual=" + idEstatisticaIndividual +
                ", idJogador=" + idJogador +
                ", golos=" + golos +
                ", assistencias=" + assistencias +
                ", jogos=" + jogos +
                ", minutosJogados=" + minutosJogados +
                ", cartoesAmarelos=" + cartoesAmarelos +
                ", cartoesVermelhos=" + cartoesVermelhos +
                '}';
    }
}

