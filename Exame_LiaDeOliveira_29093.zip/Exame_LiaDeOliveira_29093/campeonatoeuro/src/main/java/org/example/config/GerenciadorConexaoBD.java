package org.example.config;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import org.example.constantes.ConstantesBD;

public class GerenciadorConexaoBD implements IGerenciadorConexaoBD {
        private static final String USUARIO = ConstantesBD.USUARIO;
        private static final String SENHA = ConstantesBD.SENHA;
        private static final String PORTA = ConstantesBD.PORTA;
        private static final String NOMEBD = ConstantesBD.NOME_BD;
        private static final String TIPO = ConstantesBD.TIPO_DB;
        private static final String HOST = ConstantesBD.HOST;
        private static final String URL = "jdbc:" + TIPO + "://" + HOST + ":" + PORTA + "/" + NOMEBD;
        private static final String URLPADRAO = "jdbc:mysql://localhost:3306/mysql";
        private Connection connection;

        static {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
            } catch (ClassNotFoundException e) {
                throw new RuntimeException("Erro ao carregar o driver do MySQL", e);
            }
        }

        @Override
        public void abrirConexao() {
            try {
                if (connection == null || connection.isClosed()) {
                    connection = DriverManager.getConnection(URL, USUARIO, SENHA);
                }
            } catch (SQLException e) {
                e.printStackTrace();
                throw new RuntimeException("Erro ao conectar com o DB", e);
            }
        }

        public Connection getConnectionToDefaultDb() throws SQLException {
            return DriverManager.getConnection(URLPADRAO, USUARIO, SENHA);
        }

        @Override
        public Connection obterConexao() throws SQLException {
            if (connection == null || connection.isClosed()) {
                abrirConexao();
                System.out.println("Conexão com DB aberta");
            }
            return connection;
        }

        @Override
        public void fecharConexao() {
            try {
                if (connection != null && !connection.isClosed()) {
                    connection.close();
                    connection = null;
                    System.out.println("Conexão com DB fechada");
                }
            } catch (SQLException e) {
                e.printStackTrace();
                throw new RuntimeException("Erro ao fechar a conexão com o DB", e);
            }
        }

}
