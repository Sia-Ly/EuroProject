package org.example.gestao;

import org.example.dao.SelecaoDAO;
import org.example.dao.PaisDAO;
import org.example.modelos.Selecao;
import org.example.modelos.Pais;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class GestaoSelecao {
    private final SelecaoDAO selecaoDAO;
    private final PaisDAO paisDAO;
    private final Scanner scanner;

    public GestaoSelecao() {
        this.selecaoDAO = new SelecaoDAO();
        this.paisDAO = new PaisDAO();
        this.scanner = new Scanner(System.in);
    }

    public void menu() {
        int opcao;
        do {
            System.out.println("Gestão de Seleções");
            System.out.println("1. Adicionar Seleção");
            System.out.println("2. Listar Seleções");
            System.out.println("3. Atualizar Seleção");
            System.out.println("4. Remover Seleção");
            System.out.println("5. Voltar ao Menu Principal");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (opcao) {
                case 1 -> adicionarSelecao();
                case 2 -> listarSelecoes();
                case 3 -> atualizarSelecao();
                case 4 -> removerSelecao();
                case 5 -> System.out.println("Voltando ao Menu Principal...");
                default -> System.out.println("Opção inválida! Tente novamente.");
            }
        } while (opcao != 5);
    }

    private void adicionarSelecao() {
        List<Pais> paises = paisDAO.buscarTodos();
        if (paises.isEmpty()) {
            System.out.println("Nenhum país encontrado. Adicione um país primeiro.");
            return;
        }

        System.out.print("Digite o nome da seleção: ");
        String nome = scanner.nextLine();

        System.out.println("Selecione o país:");
        for (int i = 0; i < paises.size(); i++) {
            System.out.println((i + 1) + ". " + paises.get(i).getNome());
        }
        int escolhaPais = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        Pais paisSelecionado = paises.get(escolhaPais - 1);

        Selecao selecao = new Selecao();
        selecao.setNome(nome);
        selecao.setIdPais(paisSelecionado.getIdPais());

        selecaoDAO.inserir(selecao);
        System.out.println("Seleção adicionada com sucesso!");

    }

    private void listarSelecoes() {
        List<Selecao> selecoes = selecaoDAO.buscarTodos();
        if (selecoes.isEmpty()) {
            System.out.println("Nenhuma seleção encontrada.");
        } else {
            System.out.println("Lista de Seleções:");
            for (Selecao selecao : selecoes) {
                System.out.println("ID: " + selecao.getIdSelecao() + ", Nome: " + selecao.getNome() + ", País ID: " + selecao.getIdPais());
            }
        }
    }

    private void atualizarSelecao() {
        System.out.print("Digite o ID da seleção que deseja atualizar: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        Selecao selecao = selecaoDAO.buscaPorId(id);
        if (selecao == null) {
            System.out.println("Seleção não encontrada.");
            return;
        }

        System.out.print("Digite o novo nome da seleção (atual: " + selecao.getNome() + "): ");
        String nome = scanner.nextLine();

        List<Pais> paises = paisDAO.buscarTodos();
        if (!paises.isEmpty()) {
            System.out.println("Selecione o novo país:");
            for (int i = 0; i < paises.size(); i++) {
                System.out.println((i + 1) + ". " + paises.get(i).getNome());
            }
            int escolhaPais = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            Pais paisSelecionado = paises.get(escolhaPais - 1);
            selecao.setIdPais(paisSelecionado.getIdPais());
        }

        selecao.setNome(nome);
        selecaoDAO.atualizar(selecao);
        System.out.println("Seleção atualizada com sucesso!");

    }

    private void removerSelecao() {
        System.out.print("Digite o ID da seleção que deseja remover: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        selecaoDAO.eliminar(id);
        System.out.println("Seleção removida com sucesso!");
    }
}
