package org.example.dao;
import java.util.List;

public interface IDAO<T> {
    void inserir(T t);
    void atualizar(T t);
    void eliminar(int id);
    T buscaPorId(int id);
    List<T> buscarTodos();
}
