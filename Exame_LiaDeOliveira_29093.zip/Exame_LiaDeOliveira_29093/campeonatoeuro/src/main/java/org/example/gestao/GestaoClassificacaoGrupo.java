package org.example.gestao;

import org.example.dao.ClassificacaoGrupoDAO;
import org.example.dao.GrupoDAO;
import org.example.dao.SelecaoDAO;
import org.example.modelos.ClassificacaoGrupo;
import org.example.modelos.Grupo;
import org.example.modelos.Selecao;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class GestaoClassificacaoGrupo {
    private final ClassificacaoGrupoDAO classificacaoGrupoDAO;
    private final GrupoDAO grupoDAO;
    private final SelecaoDAO selecaoDAO;
    private final Scanner scanner;

    public GestaoClassificacaoGrupo() {
        this.classificacaoGrupoDAO = new ClassificacaoGrupoDAO();
        this.grupoDAO = new GrupoDAO();
        this.selecaoDAO = new SelecaoDAO();
        this.scanner = new Scanner(System.in);
    }

    public void menu() {
        int opcao;
        do {
            System.out.println("Gestão de Classificação de Grupo");
            System.out.println("1. Adicionar Classificação de Grupo");
            System.out.println("2. Listar Classificações de Grupo");
            System.out.println("3. Atualizar Classificação de Grupo");
            System.out.println("4. Remover Classificação de Grupo");
            System.out.println("5. Voltar ao Menu Principal");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (opcao) {
                case 1 -> adicionarClassificacaoGrupo();
                case 2 -> listarClassificacoesGrupo();
                case 3 -> atualizarClassificacaoGrupo();
                case 4 -> removerClassificacaoGrupo();
                case 5 -> System.out.println("Voltando ao Menu Principal...");
                default -> System.out.println("Opção inválida! Tente novamente.");
            }
        } while (opcao != 5);
    }

    private void adicionarClassificacaoGrupo() {
        List<Grupo> grupos = grupoDAO.buscarTodos();
        if (grupos.isEmpty()) {
            System.out.println("Nenhum grupo encontrado. Adicione grupos primeiro.");
            return;
        }

        List<Selecao> selecoes = selecaoDAO.buscarTodos();
        if (selecoes.isEmpty()) {
            System.out.println("Nenhuma seleção encontrada. Adicione seleções primeiro.");
            return;
        }

        System.out.println("Selecione o grupo:");
        for (int i = 0; i < grupos.size(); i++) {
            System.out.println((i + 1) + ". " + grupos.get(i).getNome());
        }
        int grupoIndex = scanner.nextInt() - 1;
        scanner.nextLine();  // Consume newline

        if (grupoIndex < 0 || grupoIndex >= grupos.size()) {
            System.out.println("Grupo inválido. Operação cancelada.");
            return;
        }

        System.out.println("Selecione a seleção:");
        for (int i = 0; i < selecoes.size(); i++) {
            System.out.println((i + 1) + ". " + selecoes.get(i).getNome());
        }
        int selecaoIndex = scanner.nextInt() - 1;
        scanner.nextLine();  // Consume newline

        if (selecaoIndex < 0 || selecaoIndex >= selecoes.size()) {
            System.out.println("Seleção inválida. Operação cancelada.");
            return;
        }

        System.out.print("Digite os pontos: ");
        int pontos = scanner.nextInt();
        System.out.print("Digite os jogos: ");
        int jogos = scanner.nextInt();
        System.out.print("Digite as vitórias: ");
        int vitorias = scanner.nextInt();
        System.out.print("Digite os empates: ");
        int empates = scanner.nextInt();
        System.out.print("Digite as derrotas: ");
        int derrotas = scanner.nextInt();
        System.out.print("Digite os golos marcados: ");
        int golosMarcados = scanner.nextInt();
        System.out.print("Digite os golos sofridos: ");
        int golosSofridos = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        ClassificacaoGrupo classificacaoGrupo = new ClassificacaoGrupo();
        classificacaoGrupo.setIdGrupo(grupos.get(grupoIndex).getIdGrupo());
        classificacaoGrupo.setIdSelecao(selecoes.get(selecaoIndex).getIdSelecao());
        classificacaoGrupo.setPontos(pontos);
        classificacaoGrupo.setJogos(jogos);
        classificacaoGrupo.setVitorias(vitorias);
        classificacaoGrupo.setEmpates(empates);
        classificacaoGrupo.setDerrotas(derrotas);
        classificacaoGrupo.setGolosMarcados(golosMarcados);
        classificacaoGrupo.setGolosSofridos(golosSofridos);

        classificacaoGrupoDAO.inserir(classificacaoGrupo);
        System.out.println("Classificação de grupo adicionada com sucesso!");
    }

    private void listarClassificacoesGrupo() {
        List<ClassificacaoGrupo> classificacoesGrupo = classificacaoGrupoDAO.buscarTodos();
        if (classificacoesGrupo.isEmpty()) {
            System.out.println("Nenhuma classificação de grupo encontrada.");
        } else {
            System.out.println("Lista de Classificações de Grupo:");
            for (ClassificacaoGrupo classificacaoGrupo : classificacoesGrupo) {
                System.out.println("ID: " + classificacaoGrupo.getIdClassificacaoGrupo() +
                        ", Grupo ID: " + classificacaoGrupo.getIdGrupo() +
                        ", Seleção ID: " + classificacaoGrupo.getIdSelecao() +
                        ", Pontos: " + classificacaoGrupo.getPontos() +
                        ", Jogos: " + classificacaoGrupo.getJogos() +
                        ", Vitórias: " + classificacaoGrupo.getVitorias() +
                        ", Empates: " + classificacaoGrupo.getEmpates() +
                        ", Derrotas: " + classificacaoGrupo.getDerrotas() +
                        ", Golos Marcados: " + classificacaoGrupo.getGolosMarcados() +
                        ", Golos Sofridos: " + classificacaoGrupo.getGolosSofridos());
            }
        }
    }

    private void atualizarClassificacaoGrupo() {
        System.out.print("Digite o ID da classificação de grupo que deseja atualizar: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        ClassificacaoGrupo classificacaoGrupo = classificacaoGrupoDAO.buscaPorId(id);
        if (classificacaoGrupo == null) {
            System.out.println("Classificação de grupo não encontrada.");
            return;
        }

        List<Grupo> grupos = grupoDAO.buscarTodos();
        if (grupos.isEmpty()) {
            System.out.println("Nenhum grupo encontrado. Adicione grupos primeiro.");
            return;
        }

        List<Selecao> selecoes = selecaoDAO.buscarTodos();
        if (selecoes.isEmpty()) {
            System.out.println("Nenhuma seleção encontrada. Adicione seleções primeiro.");
            return;
        }

        System.out.println("Selecione o novo grupo (atual: " + classificacaoGrupo.getIdGrupo() + "):");
        for (int i = 0; i < grupos.size(); i++) {
            System.out.println((i + 1) + ". " + grupos.get(i).getNome());
        }
        int grupoIndex = scanner.nextInt() - 1;
        scanner.nextLine();  // Consume newline

        if (grupoIndex < 0 || grupoIndex >= grupos.size()) {
            System.out.println("Grupo inválido. Operação cancelada.");
            return;
        }

        System.out.println("Selecione a nova seleção (atual: " + classificacaoGrupo.getIdSelecao() + "):");
        for (int i = 0; i < selecoes.size(); i++) {
            System.out.println((i + 1) + ". " + selecoes.get(i).getNome());
        }
        int selecaoIndex = scanner.nextInt() - 1;
        scanner.nextLine();  // Consume newline

        if (selecaoIndex < 0 || selecaoIndex >= selecoes.size()) {
            System.out.println("Seleção inválida. Operação cancelada.");
            return;
        }

        System.out.print("Digite os novos pontos (atual: " + classificacaoGrupo.getPontos() + "): ");
        int pontos = scanner.nextInt();
        System.out.print("Digite os novos jogos (atual: " + classificacaoGrupo.getJogos() + "): ");
        int jogos = scanner.nextInt();
        System.out.print("Digite as novas vitórias (atual: " + classificacaoGrupo.getVitorias() + "): ");
        int vitorias = scanner.nextInt();
        System.out.print("Digite os novos empates (atual: " + classificacaoGrupo.getEmpates() + "): ");
        int empates = scanner.nextInt();
        System.out.print("Digite as novas derrotas (atual: " + classificacaoGrupo.getDerrotas() + "): ");
        int derrotas = scanner.nextInt();
        System.out.print("Digite os novos golos marcados (atual: " + classificacaoGrupo.getGolosMarcados() + "): ");
        int golosMarcados = scanner.nextInt();
        scanner.nextInt();
        System.out.print("Digite os novos golos sofridos (atual: " + classificacaoGrupo.getGolosSofridos() + "): ");
        int golosSofridos = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        classificacaoGrupo.setIdGrupo(grupos.get(grupoIndex).getIdGrupo());
        classificacaoGrupo.setIdSelecao(selecoes.get(selecaoIndex).getIdSelecao());
        classificacaoGrupo.setPontos(pontos);
        classificacaoGrupo.setJogos(jogos);
        classificacaoGrupo.setVitorias(vitorias);
        classificacaoGrupo.setEmpates(empates);
        classificacaoGrupo.setDerrotas(derrotas);
        classificacaoGrupo.setGolosMarcados(golosMarcados);
        classificacaoGrupo.setGolosSofridos(golosSofridos);

        classificacaoGrupoDAO.atualizar(classificacaoGrupo);
        System.out.println("Classificação de grupo atualizada com sucesso!");
    }

    private void removerClassificacaoGrupo() {
        System.out.print("Digite o ID da classificação de grupo que deseja remover: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        ClassificacaoGrupo classificacaoGrupo = classificacaoGrupoDAO.buscaPorId(id);
        if (classificacaoGrupo == null) {
            System.out.println("Classificação de grupo não encontrada.");
            return;
        }

        System.out.println("Tem certeza que deseja remover esta classificação de grupo? (S/N)");
        String confirmacao = scanner.nextLine().trim().toUpperCase();
        if (confirmacao.equals("S")) {
            classificacaoGrupoDAO.eliminar(id);
            System.out.println("Classificação de grupo removida com sucesso!");
        } else {
            System.out.println("Operação de remoção cancelada.");
        }
    }
}


