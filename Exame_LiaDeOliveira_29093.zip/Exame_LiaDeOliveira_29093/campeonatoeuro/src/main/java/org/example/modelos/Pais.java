package org.example.modelos;

public class Pais {
    private int idPais;
    private String nome;
    private String codigoIso;

    // Construtor vazio
    public Pais() {}

    // Construtor com parâmetros
    public Pais(int idPais, String nome, String codigoIso) {
        this.idPais = idPais;
        this.nome = nome;
        this.codigoIso = codigoIso;
    }


    public int getIdPais() {
        return idPais;
    }

    public void setIdPais(int idPais) {
        this.idPais = idPais;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCodigoIso() {
        return codigoIso;
    }

    public void setCodigoIso(String codigoIso) {
        this.codigoIso = codigoIso;
    }

    @Override
    public String toString() {
        return "Pais{" +
                "idPais=" + idPais +
                ", nome='" + nome + '\'' +
                ", codigoIso='" + codigoIso + '\'' +
                '}';
    }
}
