package org.example.modelos;

import java.sql.Timestamp;


public class Jogo {
    private int idJogo;
    private Timestamp dataHora;
    private int idEstadio;
    private int idSelecaoLocal;
    private int idSelecaoVisitante;
    private int golsLocal;
    private int golsVisitante;
    private int idGrupo;
    private int idFase;



    // Construtor vazio
    public Jogo() {}

    public Jogo(int idJogo, Timestamp dataHora, int idEstadio, int idSelecaoLocal, int idSelecaoVisitante, int golsLocal, int golsVisitante, int idGrupo, int idFase) {
        this.idJogo = idJogo;
        this.dataHora = dataHora;
        this.idEstadio = idEstadio;
        this.idSelecaoLocal = idSelecaoLocal;
        this.idSelecaoVisitante = idSelecaoVisitante;
        this.golsLocal = golsLocal;
        this.golsVisitante = golsVisitante;
        this.idGrupo = idGrupo;
        this.idFase = idFase;
    }


    public int getIdJogo() {
        return idJogo;
    }

    public void setIdJogo(int idJogo) {
        this.idJogo = idJogo;
    }

    public Timestamp getDataHora() {
        return dataHora;
    }

    public void setDataHora(Timestamp dataHora) {
        this.dataHora = dataHora;
    }

    public int getIdEstadio() {
        return idEstadio;
    }

    public void setIdEstadio(int idEstadio) {
        this.idEstadio = idEstadio;
    }

    public int getIdSelecaoLocal() {
        return idSelecaoLocal;
    }

    public void setIdSelecaoLocal(int idSelecaoLocal) {
        this.idSelecaoLocal = idSelecaoLocal;
    }

    public int getIdSelecaoVisitante() {
        return idSelecaoVisitante;
    }

    public void setIdSelecaoVisitante(int idSelecaoVisitante) {
        this.idSelecaoVisitante = idSelecaoVisitante;
    }

    public int getGolsLocal() {
        return golsLocal;
    }

    public void setGolsLocal(int golsLocal) {
        this.golsLocal = golsLocal;
    }

    public int getGolsVisitante() {
        return golsVisitante;
    }

    public void setGolsVisitante(int golsVisitante) {
        this.golsVisitante = golsVisitante;
    }

    public int getIdGrupo() {
        return idGrupo;
    }

    public void setIdGrupo(int idGrupo) {
        this.idGrupo = idGrupo;
    }

    public int getIdFase() {
        return idFase;
    }

    public void setIdFase(int idFase) {
        this.idFase = idFase;
    }

    @Override
    public String toString() {
        return "Jogo{" +
                "idJogo=" + idJogo +
                ", dataHora=" + dataHora +
                ", idEstadio=" + idEstadio +
                ", idSelecaoLocal=" + idSelecaoLocal +
                ", idSelecaoVisitante=" + idSelecaoVisitante +
                ", golsLocal=" + golsLocal +
                ", golsVisitante=" + golsVisitante +
                ", idGrupo=" + idGrupo +
                ", idFase=" + idFase +
                '}';
    }
}

