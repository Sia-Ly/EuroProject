package org.example.dao;

import org.example.config.GerenciadorConexaoBD;
import org.example.modelos.Golo;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class GoloDAO implements IDAO<Golo>{

    private final GerenciadorConexaoBD gerenciadorConexao;

    public GoloDAO() {
        this.gerenciadorConexao = new GerenciadorConexaoBD();
    }

    public void inserir(Golo golo) {
        String sql = "INSERT INTO golo (idGolo, idJogo, marcador, assistente, minuto) VALUES (?, ?, ?, ?)";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, golo.getIdGolo());
            statement.setInt(2, golo.getIdJogo());
            statement.setInt(3, golo.getMarcadorId());
            statement.setInt(4, golo.getAssistenciaId());
            statement.setInt(5, golo.getMinuto());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Golo buscaPorId(int id) {
        String sql = "SELECT * FROM golo WHERE idGolo = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return extractGoloFromResultSet(resultSet);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Golo> buscarTodos() {
        List<Golo> golos = new ArrayList<>();
        String sql = "SELECT * FROM golo";
        try (Connection connection = gerenciadorConexao.obterConexao();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {
            while (resultSet.next()) {
                golos.add(extractGoloFromResultSet(resultSet));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return golos;
    }

    public void atualizar(Golo golo) {
        String sql = "UPDATE golo SET idJogo = ?, marcador = ?, assistente = ?, minuto = ? WHERE idGolo = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, golo.getIdJogo());
            statement.setInt(2, golo.getMarcadorId());
            statement.setInt(3, golo.getAssistenciaId());
            statement.setInt(4, golo.getMinuto());
            statement.setInt(5, golo.getIdGolo());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void eliminar(int id) {
        String sql = "DELETE FROM golo WHERE idGolo = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private Golo extractGoloFromResultSet(ResultSet resultSet) throws SQLException {
        Golo golo = new Golo();
        golo.setIdGolo(resultSet.getInt("idGolo"));
        golo.setIdJogo(resultSet.getInt("idJogo"));
        golo.setMarcadorId(resultSet.getInt("marcador"));
        golo.setAssistenciaId(resultSet.getInt("assistencia"));
        golo.setMinuto(resultSet.getInt("minuto"));
        return golo;
    }
}
