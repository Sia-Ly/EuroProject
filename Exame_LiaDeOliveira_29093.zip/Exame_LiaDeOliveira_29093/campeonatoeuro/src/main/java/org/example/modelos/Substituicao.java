package org.example.modelos;

public class Substituicao {
    private int idSubstituicao;
    private int idJogo;
    private int idJogadorSaiu;
    private int idJogadorEntrou;
    private int minuto;

    // Construtor vazio
    public Substituicao() {}

    // Construtor com parâmetros
    public Substituicao(int idSubstituicao, int idJogo, int idJogadorSaiu, int idJogadorEntrou, int minuto) {
        this.idSubstituicao = idSubstituicao;
        this.idJogo = idJogo;
        this.idJogadorSaiu = idJogadorSaiu;
        this.idJogadorEntrou = idJogadorEntrou;
        this.minuto = minuto;
    }

    // Getters e setters (a serem gerados pelo IntelliJ)
    public int getIdSubstituicao() {
        return idSubstituicao;
    }

    public void setIdSubstituicao(int idSubstituicao) {
        this.idSubstituicao = idSubstituicao;
    }

    public int getIdJogo() {
        return idJogo;
    }

    public void setIdJogo(int idJogo) {
        this.idJogo = idJogo;
    }

    public int getIdJogadorSaiu() {
        return idJogadorSaiu;
    }

    public void setIdJogadorSaiu(int idJogadorSaiu) {
        this.idJogadorSaiu = idJogadorSaiu;
    }

    public int getIdJogadorEntrou() {
        return idJogadorEntrou;
    }

    public void setIdJogadorEntrou(int idJogadorEntrou) {
        this.idJogadorEntrou = idJogadorEntrou;
    }

    public int getMinuto() {
        return minuto;
    }

    public void setMinuto(int minuto) {
        this.minuto = minuto;
    }

    @Override
    public String toString() {
        return "Substituicao{" +
                "id=" + idSubstituicao +
                ", idJogo=" + idJogo +
                ", idJogadorSaiu=" + idJogadorSaiu +
                ", idJogadorEntrou=" + idJogadorEntrou +
                ", minuto=" + minuto +
                '}';
    }
}

