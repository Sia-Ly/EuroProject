package org.example.dao;

import org.example.config.GerenciadorConexaoBD;
import org.example.modelos.Substituicao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SubstituicaoDAO implements IDAO<Substituicao> {

    private final GerenciadorConexaoBD gerenciadorConexao;

    public SubstituicaoDAO() {
        this.gerenciadorConexao = new GerenciadorConexaoBD();
    }

    public void inserir(Substituicao substituicao) {
        String sql = "INSERT INTO substituicao (idSubstituicao, idJogo, minuto, idJogadorSaiu, idJogadorEntrou) VALUES (?, ?, ?, ?, ?)";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, substituicao.getIdSubstituicao());
            statement.setInt(2, substituicao.getIdJogo());
            statement.setInt(3, substituicao.getMinuto());
            statement.setInt(4, substituicao.getIdJogadorSaiu());
            statement.setInt(5, substituicao.getIdJogadorEntrou());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Substituicao buscaPorId(int id) {
        String sql = "SELECT * FROM substituicao WHERE idSubstituicao = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return extractSubstituicaoFromResultSet(resultSet);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Substituicao> buscarTodos() {
        List<Substituicao> substituicoes = new ArrayList<>();
        String sql = "SELECT * FROM substituicao";
        try (Connection connection = gerenciadorConexao.obterConexao();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {
            while (resultSet.next()) {
                substituicoes.add(extractSubstituicaoFromResultSet(resultSet));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return substituicoes;
    }

    public void atualizar(Substituicao substituicao) {
        String sql = "UPDATE substituicao SET idJogo = ?, minuto = ?, idJogadorSaiu = ?, idJogadorEntrou = ? WHERE idSubstituicao = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, substituicao.getIdJogo());
            statement.setInt(2, substituicao.getMinuto());
            statement.setInt(3, substituicao.getIdJogadorSaiu());
            statement.setInt(4, substituicao.getIdJogadorEntrou());
            statement.setInt(5, substituicao.getIdSubstituicao());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void eliminar(int id) {
        String sql = "DELETE FROM substituicao WHERE idSubstituicao = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private Substituicao extractSubstituicaoFromResultSet(ResultSet resultSet) throws SQLException {
        Substituicao substituicao = new Substituicao();
        substituicao.setIdSubstituicao(resultSet.getInt("idSubstituicao"));
        substituicao.setIdJogo(resultSet.getInt("idJogo"));
        substituicao.setMinuto(resultSet.getInt("minuto"));
        substituicao.setIdJogadorSaiu(resultSet.getInt("idJogadorSai"));
        substituicao.setIdJogadorEntrou(resultSet.getInt("idJogadorEntra"));
        return substituicao;
    }
}
