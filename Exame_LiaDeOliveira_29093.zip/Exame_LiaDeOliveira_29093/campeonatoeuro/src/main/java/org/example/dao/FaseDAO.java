package org.example.dao;

import org.example.config.GerenciadorConexaoBD;
import org.example.modelos.Fase;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FaseDAO implements IDAO<Fase> {

    private final GerenciadorConexaoBD gerenciadorConexao;

    public FaseDAO() {
        this.gerenciadorConexao = new GerenciadorConexaoBD();
    }

    public void inserir(Fase fase) {
        String sql = "INSERT INTO fase (idFase, nome) VALUES (?, ?)";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, fase.getIdFase());
            statement.setString(2, fase.getNome());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Fase buscaPorId(int id) {
        String sql = "SELECT * FROM fase WHERE idFase = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return extractFaseFromResultSet(resultSet);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Fase> buscarTodos() {
        List<Fase> fases = new ArrayList<>();
        String sql = "SELECT * FROM fase";
        try (Connection connection = gerenciadorConexao.obterConexao();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {
            while (resultSet.next()) {
                fases.add(extractFaseFromResultSet(resultSet));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return fases;
    }

    public void atualizar(Fase fase) {
        String sql = "UPDATE fase SET nome = ? WHERE idFase = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, fase.getNome());
            statement.setInt(2, fase.getIdFase());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void eliminar(int id) {
        String sql = "DELETE FROM fase WHERE idFase = ?";
        try (Connection connection = gerenciadorConexao.obterConexao();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private Fase extractFaseFromResultSet(ResultSet resultSet) throws SQLException {
        Fase fase = new Fase();
        fase.setIdFase(resultSet.getInt("idFase"));
        fase.setNome(resultSet.getString("nome"));
        return fase;
    }
}

