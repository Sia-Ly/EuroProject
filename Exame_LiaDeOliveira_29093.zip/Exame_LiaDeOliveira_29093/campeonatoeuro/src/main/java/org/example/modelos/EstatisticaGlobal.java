package org.example.modelos;

public class EstatisticaGlobal {
    private int idEstatisticaGlobal;
    private int idJogo;
    private int idSelecao;
    private int remates;
    private int livres;
    private int forasJogo;

    public EstatisticaGlobal() { }

   public EstatisticaGlobal(int idJogo, int idSelecao, int remates, int livres, int forasJogo) {
       this.idJogo =idJogo;
       this.idSelecao =idSelecao;
       this.remates =remates;
       this.livres =livres;
       this.forasJogo =forasJogo;
   }


    public int getIdEstatisticaGlobal() {
        return idEstatisticaGlobal;
    }

    public void setIdEstatisticaGlobal(int idEstatisticaGlobal) {
        this.idEstatisticaGlobal = idEstatisticaGlobal;
    }

    public int getIdJogo() {
        return idJogo;
    }

    public void setIdJogo(int idJogo) {
        this.idJogo = idJogo;
    }

    public int getIdSelecao() {
        return idSelecao;
    }

    public void setIdSelecao(int idSelecao) {
        this.idSelecao = idSelecao;
    }

    public int getRemates() {
        return remates;
    }

    public void setRemates(int remates) {
        this.remates = remates;
    }

    public int getLivres() {
        return livres;
    }

    public void setLivres(int livres) {
        this.livres = livres;
    }

    public int getForasJogo() {
        return forasJogo;
    }

    public void setForasJogo(int forasDeJogo) {
        this.forasJogo = forasDeJogo;
    }

    @Override
    public String toString() {
        return "EstatisticaGlobal{" +
                "idEstatisticaGlobal=" + idEstatisticaGlobal +
                ", idJogo=" + idJogo +
                ", idSelecao=" + idSelecao +
                ", remates=" + remates +
                ", livres=" + livres +
                ", foras de Jogo=" + forasJogo +
                '}';
    }
}
