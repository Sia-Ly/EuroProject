package org.example.modelos;

public class Cartao {
    private int idCartao;
    private int idJogo;
    private int idJogador;
    private String tipo;
    private int minuto;


    public Cartao() { }

    public Cartao(int idCartao, int idJogo, int idJogador, int minuto, String tipo) {
        this.idCartao =idCartao;
        this.idJogo =idJogo;
        this.idJogador = idJogador;
        this.minuto =minuto;
        this.tipo =tipo;
    }


    public int getIdCartao() {
        return idCartao;
    }

    public void setIdCartao(int idCartao) {
        this.idCartao = idCartao;
    }

    public int getIdJogo() {
        return idJogo;
    }

    public void setIdJogo(int idJogo) {
        this.idJogo = idJogo;
    }

    public int getMinuto() {
        return minuto;
    }

    public void setMinuto(int minuto) {
        this.minuto = minuto;
    }

    public int getIdJogador() {
        return idJogador;
    }

    public void setIdJogador(int idJogador) {
        this.idJogador = idJogador;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "Cartao{" +
                "idCartao=" + idCartao +
                ", idJogo=" + idJogo +
                ", minuto=" + minuto +
                ", tipo='" + tipo + '\'' +
                '}';
    }
}
