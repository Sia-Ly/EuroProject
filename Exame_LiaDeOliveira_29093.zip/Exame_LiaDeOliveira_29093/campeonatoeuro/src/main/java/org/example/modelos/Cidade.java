package org.example.modelos;

public class Cidade {
    private int idCidade;
    private String nome;
    private int idPais;

    // Construtor vazio
    public Cidade() {}

    // Construtor com parâmetros
    public Cidade( String nome, int idPais) {
        this.nome = nome;
        this.idPais = idPais;
    }

    public int getIdCidade() {
        return idCidade;
    }

    public void setIdCidade(int idCidade) {
        this.idCidade = idCidade;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdPais() {
        return idPais;
    }

    public void setIdPais(int idPais) {
        this.idPais = idPais;
    }

    @Override
    public String toString() {
        return "Cidade{" +
                "idCidade=" + idCidade +
                ", nome='" + nome + '\'' +
                ", idPais=" + idPais +
                '}';
    }
}
