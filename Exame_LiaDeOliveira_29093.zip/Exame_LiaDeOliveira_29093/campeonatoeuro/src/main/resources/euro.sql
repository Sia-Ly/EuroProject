DROP DATABASE IF EXISTS euro;

CREATE DATABASE euro;

USE euro;
CREATE TABLE pais (
    idPais SERIAL PRIMARY KEY ,
    nome VARCHAR(100) NOT NULL,
    codigoIso VARCHAR(3) NOT NULL

);

CREATE TABLE cidade (
      idCidade SERIAL PRIMARY KEY ,
      nome VARCHAR(100) NOT NULL,
      idPais INT,
      FOREIGN KEY (idPais) REFERENCES pais(idPais) ON DELETE CASCADE

);

CREATE TABLE estadio (
       idEstadio SERIAL PRIMARY KEY ,
       nome VARCHAR(100) NOT NULL,
       capacidade INT,
       idCidade INT,
       FOREIGN KEY (idCidade) REFERENCES cidade(idCidade) ON DELETE CASCADE

);

CREATE TABLE selecao (
       idSelecao SERIAL PRIMARY KEY ,
       nome VARCHAR(100) NOT NULL,
       idPais INT,
       FOREIGN KEY (idPais) REFERENCES pais(idPais) ON DELETE CASCADE

);

CREATE TABLE jogador (
       idJogador SERIAL  PRIMARY KEY ,
       nome VARCHAR(100) NOT NULL,
       dataNascimento DATE,
       posicao VARCHAR(50),
       idSelecao INT,
       FOREIGN KEY (idSelecao) REFERENCES selecao(idSelecao) ON DELETE CASCADE

);

CREATE TABLE fase (
    idFase SERIAL PRIMARY KEY ,
    nome VARCHAR(50) NOT NULL

);

CREATE TABLE grupo (
     idGrupo SERIAL PRIMARY KEY ,
     nome VARCHAR(50) NOT NULL,
     idFase INT,
     FOREIGN KEY (idFase) REFERENCES fase(idFase) ON DELETE CASCADE

);

CREATE TABLE IF NOT EXISTS calendario(
     idCalendario SERIAL PRIMARY KEY ,
     data TIMESTAMP NOT NULL,
     idFase INT,
     idEstadio INT,
     FOREIGN KEY (idFase) REFERENCES fase(idFase) ON DELETE CASCADE,
     FOREIGN KEY (idEstadio) REFERENCES estadio(idEstadio) ON DELETE CASCADE

);

CREATE TABLE jogo (
    idJogo SERIAL PRIMARY KEY ,
    dataHora TIMESTAMP,
    idEstadio INT,
    isSelecaoLocal INT,
    idSelecaoVisitante INT,
    golsLocal INT DEFAULT 0,
    golsVisitante INT DEFAULT 0,
    idGrupo INT,
    idFase INT,
    FOREIGN KEY (idEstadio) REFERENCES estadio(idEstadio) ON DELETE CASCADE,
    FOREIGN KEY (isSelecaoLocal) REFERENCES selecao(idSelecao) ON DELETE CASCADE,
    FOREIGN KEY (idSelecaoVisitante) REFERENCES selecao(idSelecao) ON DELETE CASCADE,
    FOREIGN KEY (idGrupo) REFERENCES grupo(idGrupo) ON DELETE CASCADE,
    FOREIGN KEY (idFase) REFERENCES fase(idFase) ON DELETE CASCADE

);

CREATE TABLE golo (
    idGolo SERIAL PRIMARY KEY ,
    idJogo INT,
    marcador INT,
    assistente INT,
    minuto INT,
    penalti BOOLEAN DEFAULT FALSE,
    goloPropria BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (idJogo) REFERENCES jogo(idJogo) ON DELETE CASCADE,
    FOREIGN KEY (marcador) REFERENCES jogador(idJogador),
    FOREIGN KEY (assistente) REFERENCES jogador(idJogador)

);

CREATE TABLE classificacaoGrupo (
idClassificacaoGrupo SERIAL PRIMARY KEY ,
idGrupo INT,
idSelecao INT,
pontos INT DEFAULT 0,
jogos INT DEFAULT 0,
vitorias INT DEFAULT 0,
empates INT DEFAULT 0,
derrotas INT DEFAULT 0,
golosMarcados INT DEFAULT 0,
golosSofridos INT DEFAULT 0,
FOREIGN KEY (idGrupo) REFERENCES grupo(idGrupo) ON DELETE CASCADE,
FOREIGN KEY (idSelecao) REFERENCES selecao(idSelecao) ON DELETE CASCADE

);

CREATE TABLE classificacaoFase (
      idClassificacaoFase SERIAL PRIMARY KEY ,
      idFase INT,
      idSelecao INT,
      posicao INT,
      FOREIGN KEY (idFase) REFERENCES fase(idFase) ON DELETE CASCADE,
      FOREIGN KEY (idSelecao) REFERENCES selecao(idSelecao) ON DELETE CASCADE

);

-- Tabela de Substituições
CREATE TABLE substituicao (
 idSubstituicao SERIAL PRIMARY KEY ,
 idJogo INT,
 idJogadorSaiu INT,
 idJogadorEntrou INT,
 minuto INT,
 FOREIGN KEY (idJogo) REFERENCES jogo(idJogo) ON DELETE CASCADE,
 FOREIGN KEY (idJogadorSaiu) REFERENCES jogador(idJogador),
 FOREIGN KEY (idJogadorEntrou) REFERENCES jogador(idJogador)

);

-- Tabela de Cartões
CREATE TABLE cartao (
      idCartao SERIAL PRIMARY KEY ,
      idJogo INT,
      idJogador INT,
      tipo VARCHAR(8) NOT NULL,
      minuto INT,
      FOREIGN KEY (idJogo) REFERENCES jogo(idJogo) ON DELETE CASCADE,
      FOREIGN KEY (idJogador) REFERENCES jogador(idJogador)

);

-- Tabela de Estatísticas Globais por Equipe
CREATE TABLE estatisticaGlobal (
      idEstatisticaGlobal SERIAL PRIMARY KEY ,
      idJogo INT,
      idSelecao INT,
      remates INT DEFAULT 0,
      livres INT DEFAULT 0,
      forasJogo INT DEFAULT 0,
      FOREIGN KEY (idJogo) REFERENCES jogo(idJogo) ON DELETE CASCADE,
      FOREIGN KEY (idSelecao) REFERENCES selecao(idSelecao) ON DELETE CASCADE

);

-- Tabela de Estatísticas Individuais
CREATE TABLE estatisticaIndividual (
   idEstatisticaIndividual SERIAL PRIMARY KEY ,
   idJogador INT,
   golos INT DEFAULT 0,
   assistencias INT DEFAULT 0,
   jogos INT DEFAULT 0,
   minutosJogados INT DEFAULT 0,
   cartoesAmarelos INT DEFAULT 0,
   cartoesVermelhos INT DEFAULT 0,
   FOREIGN KEY (idJogador) REFERENCES jogador(idJogador) ON DELETE CASCADE

);
-- Trigger para atualizar estatísticas após inserção de um golo
CREATE TRIGGER atualiza_estatisticas_apos_golo
    AFTER INSERT ON golo
    FOR EACH ROW
BEGIN
    -- Atualiza estatísticas do marcador
    INSERT INTO estatisticaIndividual (idJogador, golos)
    VALUES (NEW.marcador, 1)
    ON DUPLICATE KEY UPDATE golos = golos + 1;

    -- Atualiza estatísticas do assistente (se houver)
    IF NEW.assistente IS NOT NULL THEN
        INSERT INTO estatisticaIndividual (idJogador, assistencias)
        VALUES (NEW.assistente, 1)
        ON DUPLICATE KEY UPDATE assistencias = assistencias + 1;
    END IF;
END;

-- Trigger para atualizar estatísticas após inserção de uma substituição
CREATE TRIGGER atualiza_estatisticas_apos_substituicao
    AFTER INSERT ON substituicao
    FOR EACH ROW
BEGIN
    -- Atualiza jogos para o jogador que entrou
    UPDATE estatisticaIndividual
    SET jogos = jogos + 1
    WHERE idJogador = NEW.idJogadorEntrou;
END;

-- Trigger para atualizar estatísticas após inserção de um cartão
CREATE TRIGGER atualiza_estatisticas_apos_cartao
    AFTER INSERT ON cartao
    FOR EACH ROW
BEGIN
    IF NEW.tipo = 'AMARELO' THEN
        UPDATE estatisticaIndividual
        SET cartoesAmarelos = cartoesAmarelos + 1
        WHERE idJogador = NEW.idJogador;
    ELSEIF NEW.tipo = 'VERMELHO' THEN
        UPDATE estatisticaIndividual
        SET cartoesVermelhos = cartoesVermelhos + 1
        WHERE idJogador = NEW.idJogador;
    END IF;
END;

-- Trigger para atualizar estatísticas após inserção de um jogo
CREATE TRIGGER atualiza_estatisticas_apos_jogo
    AFTER INSERT ON jogo
    FOR EACH ROW
BEGIN
    -- Atualiza classificação do grupo para a equipe local
    INSERT INTO classificacaoGrupo (idGrupo, idSelecao, jogos, pontos, vitorias, empates, derrotas, golosMarcados, golosSofridos)
    VALUES (NEW.idGrupo, NEW.isSelecaoLocal, 1,
 CASE
     WHEN NEW.golsLocal > NEW.golsVisitante THEN 3
     WHEN NEW.golsLocal = NEW.golsVisitante THEN 1
     ELSE 0
     END,
 CASE WHEN NEW.golsLocal > NEW.golsVisitante THEN 1 ELSE 0 END,
 CASE WHEN NEW.golsLocal = NEW.golsVisitante THEN 1 ELSE 0 END,
 CASE WHEN NEW.golsLocal < NEW.golsVisitante THEN 1 ELSE 0 END,
 NEW.golsLocal, NEW.golsVisitante)
    ON DUPLICATE KEY UPDATE
       jogos = jogos + 1,
       pontos = pontos + CASE
WHEN NEW.golsLocal > NEW.golsVisitante THEN 3
WHEN NEW.golsLocal = NEW.golsVisitante THEN 1
ELSE 0
END,
       vitorias = vitorias + CASE WHEN NEW.golsLocal > NEW.golsVisitante THEN 1 ELSE 0 END,
       empates = empates + CASE WHEN NEW.golsLocal = NEW.golsVisitante THEN 1 ELSE 0 END,
       derrotas = derrotas + CASE WHEN NEW.golsLocal < NEW.golsVisitante THEN 1 ELSE 0 END,
       golosMarcados = golosMarcados + NEW.golsLocal,
       golosSofridos = golosSofridos + NEW.golsVisitante;

    -- Atualiza classificação do grupo para a equipe visitante
    INSERT INTO classificacaoGrupo (idGrupo, idSelecao, jogos, pontos, vitorias, empates, derrotas, golosMarcados, golosSofridos)
    VALUES (NEW.idGrupo, NEW.idSelecaoVisitante, 1,
 CASE
     WHEN NEW.golsVisitante > NEW.golsLocal THEN 3
     WHEN NEW.golsVisitante = NEW.golsLocal THEN 1
     ELSE 0
     END,
 CASE WHEN NEW.golsVisitante > NEW.golsLocal THEN 1 ELSE 0 END,
 CASE WHEN NEW.golsVisitante = NEW.golsLocal THEN 1 ELSE 0 END,
 CASE WHEN NEW.golsVisitante < NEW.golsLocal THEN 1 ELSE 0 END,
 NEW.golsVisitante, NEW.golsLocal)
    ON DUPLICATE KEY UPDATE
       jogos = jogos + 1,
       pontos = pontos + CASE
WHEN NEW.golsVisitante > NEW.golsLocal THEN 3
WHEN NEW.golsVisitante = NEW.golsLocal THEN 1
ELSE 0
END,
       vitorias = vitorias + CASE WHEN NEW.golsVisitante > NEW.golsLocal THEN 1 ELSE 0 END,
       empates = empates + CASE WHEN NEW.golsVisitante = NEW.golsLocal THEN 1 ELSE 0 END,
       derrotas = derrotas + CASE WHEN NEW.golsVisitante < NEW.golsLocal THEN 1 ELSE 0 END,
       golosMarcados = golosMarcados + NEW.golsVisitante,
       golosSofridos = golosSofridos + NEW.golsLocal;
END;

-- View de Estatísticas Individuais
CREATE VIEW v_estatisticas_individuais AS
SELECT
    j.idJogador AS jogador_id,
    j.nome AS jogador_nome,
    s.nome AS selecao_nome,
    ei.golos,
    ei.assistencias,
    ei.jogos,
    ei.minutosJogados,
    ei.cartoesAmarelos,
    ei.cartoesVermelhos
FROM
    estatisticaIndividual ei
        JOIN jogador j ON ei.idJogador = j.idJogador
        JOIN selecao s ON j.idSelecao = s.idSelecao
ORDER BY
    ei.golos DESC, ei.assistencias DESC;

-- View de Estatísticas Globais por Equipe
CREATE VIEW v_estatisticas_globais AS
SELECT
    j.idJogo AS idJogo,
    e.nome AS estadio_nome,
    c.nome AS cidade_nome,
    sl.nome AS selecao_local,
    sv.nome AS selecao_visitante,
    eg.remates AS remates_local,
    eg.livres AS livres_local,
    eg.forasJogo AS foras_jogo_local,
    eg2.remates AS remates_visitante,
    eg2.livres AS livres_visitante,
    eg2.forasJogo AS foras_jogo_visitante,
    j.dataHora
FROM
    jogo j
        JOIN estadio e ON j.idEstadio = e.idEstadio
        JOIN cidade c ON e.idCidade = c.idCidade
        JOIN selecao sl ON j.isSelecaoLocal = sl.idSelecao
        JOIN selecao sv ON j.idSelecaoVisitante = sv.idSelecao
        JOIN estatisticaGlobal eg ON j.idJogo = eg.idJogo AND sl.idSelecao = eg.idSelecao
        JOIN estatisticaGlobal eg2 ON j.idJogo = eg2.idJogo AND sv.idSelecao = eg2.idSelecao
ORDER BY
    j.dataHora;

